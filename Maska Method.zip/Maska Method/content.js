/**
 * TT Analytics — Content Script (v4)
 *
 * v4: Handle TRANSCODE_COMPLETED. Fallback polling fixed
 * (correct path to status, file_key placeholder).
 */

(function () {
  'use strict';

  let config = null;
  let configSentToPage = false;
  let extensionInvalidated = false;

  // Safe message sending to background
  function safeSend(msg) {
    if (extensionInvalidated) return Promise.resolve(null);
    return chrome.runtime.sendMessage(msg).catch(err => {
      if (err?.message?.includes('Extension context invalidated')) {
        extensionInvalidated = true;
        showNotification('⚠️ Extension updated! Reload page (F5)', 'error', 15000);
      }
      return null;
    });
  }

  // ═══ INTERCEPTOR INJECTION ═══

  function injectInterceptor() {
    if (document.documentElement.dataset.maskaInterceptor) return;
    document.documentElement.dataset.maskaInterceptor = '1';
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('interceptor.js');
    s.dataset.extId = chrome.runtime.id;
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);
  }

  function replyConfigToPage() {
    if (!config) return;
    window.postMessage({ dir: 'TT_FROM_BG', msg: { type: 'CONFIG', config } }, '*');
    configSentToPage = true;
  }

  function fetchConfigFromBackground() {
    return safeSend({ type: 'GET_CONFIG' }).then(res => {
      if (res?.config) {
        config = res.config;
        replyConfigToPage();
      }
      return config;
    });
  }

  // ═══ BRIDGE: page ↔ background ═══

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.dir !== 'TT_TO_BG') return;
    const msg = e.data.msg;
    if (msg?.type === 'GET_CONFIG') {
      if (config) {
        replyConfigToPage();
      } else {
        fetchConfigFromBackground();
      }
      return;
    }
    safeSend(msg);
  });

  // ═══ COMMANDS FROM BACKGROUND ═══

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case 'CALL_TRANSCODE_ENABLE':
        callTranscodeEnable(msg.videoId, msg.poll, msg.pollInterval, msg.pollMax);
        sendResponse({ ok: true });
        break;

      case 'CONFIG_UPDATED':
        config = msg.config;
        replyConfigToPage();
        sendResponse({ ok: true });
        break;

      case 'SHOW_NOTIFICATION':
        showNotification(msg.text, msg.notifType || 'info', msg.duration);
        sendResponse({ ok: true });
        break;

      case 'TRANSCODE_COMPLETED':
        showNotification('✅ Transcode completed! You can publish.', 'success', 8000);
        sendResponse({ ok: true });
        break;

      default:
        sendResponse({});
    }
    return true;
  });

  async function bootstrap() {
    for (let i = 0; i < 8; i++) {
      await fetchConfigFromBackground();
      if (config) break;
      await new Promise(r => setTimeout(r, 150 * (i + 1)));
    }
    injectInterceptor();
    replyConfigToPage();
    if (!config) {
      setTimeout(fetchConfigFromBackground, 500);
      setTimeout(fetchConfigFromBackground, 2000);
    }
  }

  bootstrap();

  // ═══ TRANSCODE/ENABLE API ═══

  async function callTranscodeEnable(videoId, poll, pollInterval, pollMax) {
    console.log('[TT] 🚀 Calling transcode/enable for', videoId);
    showNotification('Calling transcode/enable...', 'info');

    try {
      // Step 1: GET CSRF token via HEAD
      const apiUrl = 'https://www.tiktok.com/api/v1/video/transcode/enable/?video_id=' +
        encodeURIComponent(videoId) + '&aid=1988';

      const headRes = await fetch(apiUrl, {
        method: 'HEAD',
        credentials: 'include',
        headers: {
          'x-secsdk-csrf-request': '1',
          'x-secsdk-csrf-version': '1.2.22'
        }
      });

      // Extract token
      const csrfHeader = headRes.headers.get('x-ware-csrf-token');
      let token = null;
      if (csrfHeader) {
        const parts = csrfHeader.split(',');
        if (parts.length >= 2) token = parts[1];
      }

      console.log('[TT] CSRF token:', token ? 'received' : 'NOT RECEIVED');

      // Step 2: POST with token
      const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'x-secsdk-csrf-version': '1.2.22'
      };
      if (token) {
        headers['tt-csrf-token'] = token;
        headers['x-secsdk-csrf-token'] = token;
      }

      const postRes = await fetch(apiUrl, {
        method: 'POST',
        credentials: 'include',
        headers,
      });

      const result = await postRes.json();
      console.log('[TT] ✅ transcode/enable result:', result);

      safeSend({
        type: 'TRANSCODE_RESULT',
        status: 'enabled',
        detail: JSON.stringify(result).slice(0, 500),
        videoId
      });

      showNotification('transcode/enable: OK ✓', 'success');

      // Step 3: Poll transcode/result
      if (poll) {
        pollTranscodeResult(videoId, pollInterval || 2000, pollMax || 30);
      }

    } catch (err) {
      console.error('[TT] ❌ transcode/enable error:', err);
      showNotification('transcode/enable: ERROR', 'error');
      safeSend({
        type: 'TRANSCODE_RESULT',
        status: 'error',
        detail: err.message,
        videoId
      });
    }
  }

  async function pollTranscodeResult(videoId, interval, maxAttempts) {
    const url = 'https://www.tiktok.com/api/v1/video/transcode/result/?aid=1988';
    let attempts = 0;

    const doPoll = async () => {
      if (attempts >= maxAttempts) {
        console.log('[TT] Polling timeout after', attempts, 'attempts');
        showNotification('Transcode: timeout (' + attempts + ' attempts)', 'warning');
        return;
      }
      attempts++;

      try {
        // CSRF
        const headRes = await fetch(url, {
          method: 'HEAD', credentials: 'include',
          headers: { 'x-secsdk-csrf-request': '1', 'x-secsdk-csrf-version': '1.2.22' }
        });
        const csrfH = headRes.headers.get('x-ware-csrf-token');
        let tk = null;
        if (csrfH) { const p = csrfH.split(','); if (p.length >= 2) tk = p[1]; }

        const hdrs = { 'Content-Type': 'application/json', 'x-secsdk-csrf-version': '1.2.22' };
        if (tk) { hdrs['tt-csrf-token'] = tk; hdrs['x-secsdk-csrf-token'] = tk; }

        const body = JSON.stringify({
          scene: 0,
          video_info: [{
            file_key: '', video_id: videoId,
            original_width: 1080, original_height: 1080, original_duration_ms: 0
          }]
        });

        const res = await fetch(url, { method: 'POST', credentials: 'include', headers: hdrs, body });
        const data = await res.json();

        // FIXED v4: correct path to status
        const tr = data?.transcode_result;
        const st = tr && tr[0] ? tr[0].transcode_status : undefined;
        console.log('[TT] Transcode polling #' + attempts + ': status=' + st);

        safeSend({
          type: 'TRANSCODE_RESULT',
          status: 'polling',
          pollAttempt: attempts,
          transcodeStatus: st,
          detail: JSON.stringify(data).slice(0, 500),
          videoId
        });

        if (st === 3) {
          console.log('[TT] ✅ Transcode completed!');
          showNotification('Transcode completed! ✓', 'success');
          return;
        }

        setTimeout(doPoll, interval);
      } catch (err) {
        console.error('[TT] Polling error:', err);
        setTimeout(doPoll, interval);
      }
    };

    setTimeout(doPoll, interval);
  }

  // ═══ NOTIFICATIONS ON PAGE ═══

  function showNotification(text, type, duration) {
    const id = 'tt-notif-' + Date.now();
    const colors = {
      info: '#1a90ff', success: '#00c853', error: '#ff1744', warning: '#ff9100'
    };

    // Shift notifications down if there are others
    const existing = document.querySelectorAll('[id^="tt-notif-"]');
    const topOffset = 10 + existing.length * 46;

    const div = document.createElement('div');
    div.id = id;
    div.style.cssText = 'position:fixed;top:' + topOffset + 'px;right:10px;z-index:999999;' +
      'padding:10px 16px;border-radius:8px;font-size:13px;font-family:sans-serif;' +
      'color:white;background:' + (colors[type] || colors.info) + ';' +
      'box-shadow:0 4px 12px rgba(0,0,0,0.3);transition:opacity 0.3s;opacity:1;';
    div.textContent = '[Maska] ' + text;
    document.body.appendChild(div);

    setTimeout(() => {
      div.style.opacity = '0';
      setTimeout(() => div.remove(), 300);
    }, duration || 3000);
  }

  console.log('[TT] Content script v3.1 loaded.');
})();
