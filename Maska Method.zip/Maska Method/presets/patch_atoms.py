#!/usr/bin/env python3
"""
MP4 Atom Patcher — меняет width/height в tkhd атоме.
Идея: если tkhd говорит 720p, а реальные кадры 1080p,
TikTok может пропустить даунскейл.

Использование:
  python patch_atoms.py video.mp4 720 1280
  python patch_atoms.py video.mp4 3840 2160  (fake 4K)
"""

import struct
import sys
import os

def find_atom(data, atom_type, start=0):
    """Находит атом по типу, возвращает (offset, size)."""
    pos = start
    while pos < len(data) - 8:
        size = struct.unpack('>I', data[pos:pos+4])[0]
        atype = data[pos+4:pos+8]
        if size < 8:
            break
        if atype == atom_type:
            return pos, size
        pos += size
    return None, None

def find_atom_recursive(data, path, start=0, end=None):
    """Находит вложенный атом по пути, напр. [b'moov', b'trak', b'tkhd']."""
    if end is None:
        end = len(data)
    
    pos = start
    target = path[0]
    
    while pos < end - 8:
        size = struct.unpack('>I', data[pos:pos+4])[0]
        atype = data[pos+4:pos+8]
        if size < 8:
            break
        
        if atype == target:
            if len(path) == 1:
                return pos, size
            # Контейнерный атом — ищем внутри (пропускаем header 8 байт)
            inner_start = pos + 8
            # Для moov, trak, mdia, minf, stbl — просто вложенные атомы
            result = find_atom_recursive(data, path[1:], inner_start, pos + size)
            if result[0] is not None:
                return result
        
        pos += size
    
    return None, None

def patch_tkhd(data, new_width, new_height):
    """Патчит width и height в tkhd атоме."""
    # Находим moov → trak → tkhd
    tkhd_pos, tkhd_size = find_atom_recursive(data, [b'moov', b'trak', b'tkhd'])
    
    if tkhd_pos is None:
        print("ОШИБКА: tkhd атом не найден!")
        return data
    
    print(f"  tkhd найден на offset {tkhd_pos}, размер {tkhd_size}")
    
    # tkhd structure:
    # 4 bytes: size
    # 4 bytes: 'tkhd'
    # 1 byte: version (0 or 1)
    # 3 bytes: flags
    # version 0: 4+4+4+4+4+2+2+2*4+9*4+4+4 = creation, modification, track_id, reserved, duration, ...
    # version 1: 8+8+4+4+8+... = 
    
    header = tkhd_pos + 8  # skip size + type
    version = data[header]
    
    if version == 0:
        # v0: 4(version+flags) + 4(creation) + 4(modification) + 4(track_id) + 4(reserved) + 4(duration)
        #     + 8(reserved) + 2(layer) + 2(alternate_group) + 2(volume) + 2(reserved)
        #     + 36(matrix) + 4(width) + 4(height)
        width_offset = header + 4 + 4 + 4 + 4 + 4 + 4 + 8 + 2 + 2 + 2 + 2 + 36
        height_offset = width_offset + 4
    elif version == 1:
        # v1: 4(version+flags) + 8(creation) + 8(modification) + 4(track_id) + 4(reserved) + 8(duration)
        #     + 8(reserved) + 2(layer) + 2(alternate_group) + 2(volume) + 2(reserved)
        #     + 36(matrix) + 4(width) + 4(height)
        width_offset = header + 4 + 8 + 8 + 4 + 4 + 8 + 8 + 2 + 2 + 2 + 2 + 36
        height_offset = width_offset + 4
    else:
        print(f"  Неизвестная версия tkhd: {version}")
        return data
    
    # Width и Height — fixed-point 16.16
    old_width_raw = struct.unpack('>I', data[width_offset:width_offset+4])[0]
    old_height_raw = struct.unpack('>I', data[height_offset:height_offset+4])[0]
    old_width = old_width_raw >> 16
    old_height = old_height_raw >> 16
    
    print(f"  Текущие размеры: {old_width}x{old_height}")
    print(f"  Новые размеры:   {new_width}x{new_height}")
    
    # Патчим
    new_width_fp = new_width << 16
    new_height_fp = new_height << 16
    
    data = bytearray(data)
    struct.pack_into('>I', data, width_offset, new_width_fp)
    struct.pack_into('>I', data, height_offset, new_height_fp)
    
    # Верифицируем
    verify_w = struct.unpack('>I', data[width_offset:width_offset+4])[0] >> 16
    verify_h = struct.unpack('>I', data[height_offset:height_offset+4])[0] >> 16
    print(f"  Верификация:     {verify_w}x{verify_h} ✓")
    
    return bytes(data)

def patch_stsd(data, new_width, new_height):
    """Патчит width/height в stsd → avc1/hev1 атоме."""
    # moov → trak → mdia → minf → stbl → stsd
    stsd_pos, stsd_size = find_atom_recursive(
        data, [b'moov', b'trak', b'mdia', b'minf', b'stbl', b'stsd']
    )
    
    if stsd_pos is None:
        print("  stsd атом не найден (пропускаем)")
        return data
    
    print(f"  stsd найден на offset {stsd_pos}, размер {stsd_size}")
    
    # stsd: size(4) + 'stsd'(4) + version+flags(4) + entry_count(4) + entries...
    # Каждый entry для видео (avc1/hev1/etc):
    # size(4) + type(4) + reserved(6) + data_ref_index(2) + pre_defined(2) + reserved(2)
    # + pre_defined(12) + width(2) + height(2) + ...
    
    entry_start = stsd_pos + 8 + 4 + 4  # skip stsd header + version + count
    
    # Ищем видео entry (avc1, hev1, hvc1, avc3)
    video_types = [b'avc1', b'hev1', b'hvc1', b'avc3']
    
    pos = entry_start
    end = stsd_pos + stsd_size
    
    data = bytearray(data)
    patched = False
    
    while pos < end - 8:
        entry_size = struct.unpack('>I', data[pos:pos+4])[0]
        entry_type = bytes(data[pos+4:pos+8])
        
        if entry_size < 8:
            break
        
        if entry_type in video_types:
            # Width at offset 24, Height at offset 26 (from entry start)
            # entry: size(4) + type(4) + reserved(6) + data_ref_index(2) + 
            #        pre_defined(2) + reserved(2) + pre_defined(12) + width(2) + height(2)
            w_offset = pos + 4 + 4 + 6 + 2 + 2 + 2 + 12
            h_offset = w_offset + 2
            
            old_w = struct.unpack('>H', data[w_offset:w_offset+2])[0]
            old_h = struct.unpack('>H', data[h_offset:h_offset+2])[0]
            
            print(f"  {entry_type.decode()}: {old_w}x{old_h} → {new_width}x{new_height}")
            
            struct.pack_into('>H', data, w_offset, new_width)
            struct.pack_into('>H', data, h_offset, new_height)
            patched = True
        
        pos += entry_size
    
    if not patched:
        print("  Видео entry в stsd не найден")
    
    return bytes(data)

def main():
    if len(sys.argv) < 4:
        print("Использование: python patch_atoms.py video.mp4 width height")
        print("Пример: python patch_atoms.py video.mp4 720 1280")
        sys.exit(1)
    
    filepath = sys.argv[1]
    new_width = int(sys.argv[2])
    new_height = int(sys.argv[3])
    
    if not os.path.exists(filepath):
        print(f"Файл не найден: {filepath}")
        sys.exit(1)
    
    print(f"\n═══ MP4 Atom Patcher ═══")
    print(f"Файл: {filepath}")
    print(f"Целевые размеры: {new_width}x{new_height}")
    print()
    
    with open(filepath, 'rb') as f:
        data = f.read()
    
    original_size = len(data)
    print(f"Размер файла: {original_size:,} байт ({original_size/1024/1024:.1f} MB)")
    
    # Патчим tkhd
    print("\n--- Патчим tkhd (Track Header) ---")
    data = patch_tkhd(data, new_width, new_height)
    
    # Патчим stsd (Sample Description)
    print("\n--- Патчим stsd (Sample Description) ---")
    data = patch_stsd(data, new_width, new_height)
    
    # Сохраняем
    with open(filepath, 'wb') as f:
        f.write(data)
    
    print(f"\n✓ Файл пропатчен: {filepath}")
    print(f"  Размер не изменился: {len(data):,} байт")
    print()

if __name__ == '__main__':
    main()
