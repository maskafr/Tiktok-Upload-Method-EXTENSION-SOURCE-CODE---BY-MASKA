@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ═══════════════════════════════════════════════════════════
REM TT-Analytics FFmpeg Presets v1.0
REM Подготовка видео для обхода сжатия TikTok
REM ═══════════════════════════════════════════════════════════
REM
REM ИДЕЯ: TikTok ВСЕГДА сжимает веб-загрузки до 720p 7.5MB.
REM Параметры API (cloud_edit, hd_video, etc.) НЕ влияют.
REM Единственный оставшийся вектор — изменить сам VIDEO FILE
REM до загрузки, чтобы сервер обработал его иначе.
REM
REM ИСПОЛЬЗОВАНИЕ:
REM   tt-presets.bat [номер_пресета] [входной_файл]
REM
REM Пример:
REM   tt-presets.bat 1 my_video.mp4
REM   tt-presets.bat 3 "C:\Videos\test.mp4"
REM
REM Результат сохраняется рядом с исходным файлом:
REM   my_video_preset1_4k.mp4
REM ═══════════════════════════════════════════════════════════

set PRESET=%1
set INPUT=%~2
set INPUTDIR=%~dp2
set INPUTNAME=%~n2

if "%INPUT%"=="" (
    echo.
    echo ╔══════════════════════════════════════════════════════╗
    echo ║  TT-Analytics FFmpeg Presets                        ║
    echo ╠══════════════════════════════════════════════════════╣
    echo ║                                                     ║
    echo ║  1 - Upscale 4K (3840x2160^) — самый перспективный   ║
    echo ║      Идея: TikTok сожмёт 4K→1080p вместо 1080→720  ║
    echo ║                                                     ║
    echo ║  2 - Upscale 2K (2560x1440^)                         ║
    echo ║      Идея: промежуточное разрешение                 ║
    echo ║                                                     ║
    echo ║  3 - H.265/HEVC перекодирование                     ║
    echo ║      Идея: другой кодек = другой пайплайн сервера   ║
    echo ║                                                     ║
    echo ║  4 - Fake HDR метаданные                            ║
    echo ║      Идея: HDR контент = приоритетное качество      ║
    echo ║                                                     ║
    echo ║  5 - Ultra high bitrate H.264 (50 Mbps^)             ║
    echo ║      Идея: сервер выделит больше битрейта           ║
    echo ║                                                     ║
    echo ║  6 - 720p60 pre-encode (без даунскейла^)             ║
    echo ║      Идея: уже 720p = TikTok не будет уменьшать     ║
    echo ║                                                     ║
    echo ║  7 - Atom patch: fake resolution в tkhd             ║
    echo ║      Идея: метаданные говорят 720p, кадры 1080p     ║
    echo ║                                                     ║
    echo ║  8 - COMBO: 4K + H.265 + Fake HDR                  ║
    echo ║      Идея: максимум всех трюков                     ║
    echo ║                                                     ║
    echo ╠══════════════════════════════════════════════════════╣
    echo ║  Использование: tt-presets.bat [1-8] video.mp4      ║
    echo ╚══════════════════════════════════════════════════════╝
    echo.
    exit /b 0
)

if not exist "%INPUT%" (
    echo ОШИБКА: Файл "%INPUT%" не найден!
    exit /b 1
)

REM Проверяем FFmpeg
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo ОШИБКА: FFmpeg не найден! Установите FFmpeg и добавьте в PATH.
    echo Скачать: https://ffmpeg.org/download.html
    exit /b 1
)

echo.
echo ═══ TT-Analytics FFmpeg Preset #%PRESET% ═══
echo Вход: %INPUT%
echo.

if "%PRESET%"=="1" goto PRESET_4K
if "%PRESET%"=="2" goto PRESET_2K
if "%PRESET%"=="3" goto PRESET_HEVC
if "%PRESET%"=="4" goto PRESET_HDR
if "%PRESET%"=="5" goto PRESET_HIGHBR
if "%PRESET%"=="6" goto PRESET_720P
if "%PRESET%"=="7" goto PRESET_ATOMS
if "%PRESET%"=="8" goto PRESET_COMBO

echo ОШИБКА: Неизвестный пресет %PRESET%. Используйте 1-8.
exit /b 1

:PRESET_4K
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset1_4k.mp4
echo [Пресет 1] Upscale до 4K (3840x2160)
echo Идея: TikTok сжимает 4K → 1080p (а не 1080 → 720)
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -vf "scale=3840:2160:flags=lanczos" ^
  -c:v libx264 -preset slow -crf 16 ^
  -profile:v high -level 5.2 ^
  -pix_fmt yuv420p ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_2K
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset2_2k.mp4
echo [Пресет 2] Upscale до 2K (2560x1440)
echo Идея: промежуточный размер, TikTok может дать 1080p
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -vf "scale=2560:1440:flags=lanczos" ^
  -c:v libx264 -preset slow -crf 17 ^
  -profile:v high -level 5.1 ^
  -pix_fmt yuv420p ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_HEVC
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset3_hevc.mp4
echo [Пресет 3] Перекодирование в H.265/HEVC
echo Идея: другой кодек может триггерить другой пайплайн
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -c:v libx265 -preset slow -crf 18 ^
  -pix_fmt yuv420p ^
  -tag:v hvc1 ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_HDR
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset4_hdr.mp4
echo [Пресет 4] Fake HDR метаданные (BT.2020 + PQ)
echo Идея: HDR флаги = премиальное качество обработки
echo ВНИМАНИЕ: видео НЕ будет реально HDR, только метки.
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -c:v libx265 -preset slow -crf 18 ^
  -pix_fmt yuv420p10le ^
  -color_primaries bt2020 ^
  -color_trc smpte2084 ^
  -colorspace bt2020nc ^
  -tag:v hvc1 ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_HIGHBR
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset5_highbr.mp4
echo [Пресет 5] Ultra high bitrate H.264 (50 Mbps)
echo Идея: высокий входной битрейт = больше выходного
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -c:v libx264 -preset slow ^
  -b:v 50M -maxrate 60M -bufsize 80M ^
  -profile:v high -level 4.2 ^
  -pix_fmt yuv420p ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_720P
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset6_720p60.mp4
echo [Пресет 6] Pre-encode 720p60 высокое качество
echo Идея: уже 720p = TikTok НЕ даунскейлит = меньше потерь
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -vf "scale=720:1280:flags=lanczos" ^
  -r 60 ^
  -c:v libx264 -preset slow -crf 14 ^
  -profile:v high -level 4.2 ^
  -pix_fmt yuv420p ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:PRESET_ATOMS
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset7_atoms.mp4
echo [Пресет 7] Fake resolution в атомах (tkhd=720, кадры=1080)
echo Идея: обмануть TikTok — метаданные 720p, контент 1080p
echo Выход: %OUTPUT%
echo.
REM Сначала копируем с faststart
ffmpeg -y -i "%INPUT%" ^
  -c copy ^
  -movflags +faststart ^
  "%OUTPUT%"

REM Затем патчим атомы через Python
echo Патчим MP4 атомы...
python "%~dp0patch_atoms.py" "%OUTPUT%" 720 1280
goto DONE

:PRESET_COMBO
set OUTPUT=%INPUTDIR%%INPUTNAME%_preset8_combo.mp4
echo [Пресет 8] COMBO: 4K + H.265 + Fake HDR
echo Идея: все трюки одновременно — максимальный шанс
echo ВНИМАНИЕ: файл будет БОЛЬШОЙ (100+ MB)
echo Выход: %OUTPUT%
echo.
ffmpeg -y -i "%INPUT%" ^
  -vf "scale=3840:2160:flags=lanczos" ^
  -c:v libx265 -preset slow -crf 18 ^
  -pix_fmt yuv420p10le ^
  -color_primaries bt2020 ^
  -color_trc smpte2084 ^
  -colorspace bt2020nc ^
  -tag:v hvc1 ^
  -movflags +faststart ^
  -c:a aac -b:a 192k ^
  "%OUTPUT%"
goto DONE

:DONE
if errorlevel 1 (
    echo.
    echo ═══ ОШИБКА! FFmpeg завершился с кодом ошибки. ═══
    exit /b 1
)
echo.
echo ═══ ГОТОВО! ═══
echo Файл: %OUTPUT%
for %%F in ("%OUTPUT%") do echo Размер: %%~zF байт
echo.
echo Теперь загрузи этот файл на TikTok с включённым расширением TT-Analytics.
echo Рекомендуемый конфиг: transcodeEnable + privateFirst 
echo.
exit /b 0
