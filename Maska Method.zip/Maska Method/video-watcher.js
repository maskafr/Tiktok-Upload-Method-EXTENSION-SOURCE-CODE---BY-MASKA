/**
 * Maska Method — live TikTok playback stats (FYP + video page)
 */
(function () {
  'use strict';

  if (window !== window.top) return;

  const POLL_MS = 800;
  const LOCK_RELEASE_MS = 12000;

  let lockedVideo = null;
  let lockLostAt = 0;
  let trackedVideo = null;
  let rvfHandle = null;
  let fpsSamples = [];
  let lastMediaTime = null;
  let lastStaticKey = '';
  let lastPushed = null;
  let cachedFps = '—';

  function formatTime(sec) {
    if (!isFinite(sec) || sec < 0) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return m + ':' + String(s).padStart(2, '0');
  }

  const STANDARD_TIERS = [360, 480, 540, 720, 1080, 2160];

  /**
   * Map decoded pixel size → playback tier (nearest standard, not ceiling).
   * Portrait TikTok: use width (540×960 → 540p).
   */
  function tierFromDimensions(w, h) {
    if (!w || !h) return null;
    const portrait = h > w * 1.05;
    const key = portrait ? w : h;
    if (key >= 3800) return '4K';

    let nearest = STANDARD_TIERS[0];
    let diff = Math.abs(key - nearest);
    for (const t of STANDARD_TIERS) {
      const d = Math.abs(key - t);
      if (d < diff) {
        diff = d;
        nearest = t;
      }
    }
    if (diff > 120) return null;
    if (nearest >= 2160) return '4K';
    return nearest + 'p';
  }

  function snapTierLabel(n) {
    const v = parseInt(n, 10);
    if (!v) return null;
    if (v >= 2160) return '4K';
    if (v >= 1080) return '1080p';
    if (v >= 720) return '720p';
    if (v >= 540) return '540p';
    if (v >= 480) return '480p';
    if (v >= 360) return '360p';
    return v + 'p';
  }

  /** Read quality from TikTok player / studio UI (user-selected tier) */
  function readQualityFromPage(v) {
    const root = v?.closest?.(
      '[class*="player"], [class*="Player"], [class*="video-card"], [class*="xgplayer"], [data-e2e*="video"]'
    ) || document;

    const scan = (el) => {
      if (!el || el.children?.length > 8) return null;
      const t = (el.textContent || '').trim();
      const a = (el.getAttribute?.('aria-label') || '').trim();
      for (const s of [t, a]) {
        if (!s || s.length > 32) continue;
        const m = s.match(/^(\d{3,4})\s*p$/i) || s.match(/\b(\d{3,4})p\b/i);
        if (m) return snapTierLabel(m[1]);
        if (/^auto$/i.test(s)) return 'Auto';
      }
      return null;
    };

    const active = root.querySelector(
      '[class*="quality" i][class*="active" i], [class*="quality" i][class*="selected" i], ' +
      '[class*="resolution" i][class*="active" i], [aria-checked="true"], [aria-selected="true"]'
    );
    const fromActive = active ? scan(active) : null;
    if (fromActive && fromActive !== 'Auto') return fromActive;

    const nodes = root.querySelectorAll(
      '[class*="quality" i], [class*="resolution" i], [class*="definition" i], ' +
      '[data-e2e*="quality" i], [aria-label*="quality" i], [aria-label*="resolution" i], button, span'
    );
    for (const el of nodes) {
      const q = scan(el);
      if (q && q !== 'Auto') return q;
    }
    return null;
  }

  function tierFromBitrate(br) {
    const n = Number(br);
    if (!n || n < 1) return null;
    const mbps = n > 10000 ? n / 1000000 : n / 1000;
    if (mbps >= 4.5) return '1080p';
    if (mbps >= 2.2) return '720p';
    if (mbps >= 1.2) return '540p';
    if (mbps >= 0.6) return '480p';
    return '360p';
  }

  function parseMediaUrl(url) {
    const out = { w: 0, h: 0, tier: null, bitrate: null };
    if (!url || url.startsWith('blob:')) return out;

    const s = String(url);
    const sl = s.toLowerCase();

    const wh = sl.match(/(\d{3,4})[x×](\d{3,4})/);
    if (wh) {
      out.w = parseInt(wh[1], 10);
      out.h = parseInt(wh[2], 10);
    }

    const params = [
      [/originwidth[=:](\d+)/i, 'w'],
      [/originheight[=:](\d+)/i, 'h'],
      [/origin_width[=:](\d+)/i, 'w'],
      [/origin_height[=:](\d+)/i, 'h'],
      [/[?&]width=(\d+)/i, 'w'],
      [/[?&]height=(\d+)/i, 'h'],
      [/video_width[=:](\d+)/i, 'w'],
      [/video_height[=:](\d+)/i, 'h'],
    ];
    for (const [re, key] of params) {
      const m = sl.match(re);
      if (m) out[key] = Math.max(out[key], parseInt(m[1], 10));
    }

    const def = sl.match(/definition[=:'"]*(\d{3,4})/i) ||
      sl.match(/[?&]vq=(\d)/i) ||
      sl.match(/gear[_-]?name[=:](\w+)/i);
    if (def) {
      const d = def[1];
      if (/^\d+$/.test(d)) {
        const n = parseInt(d, 10);
        if (n >= 1080) out.tier = '1080p';
        else if (n >= 720) out.tier = '720p';
        else if (n >= 540) out.tier = '540p';
        else out.tier = n + 'p';
      } else if (/1080|uhd|fhd|high|super|max|hd_1080/.test(d)) out.tier = '1080p';
      else if (/720|hd|medium|normal_720/.test(d)) out.tier = '720p';
      else if (/540/.test(d)) out.tier = '540p';
      else if (/480|low/.test(d)) out.tier = '480p';
    }

    if (/1080p|_1080_|\/1080\//.test(sl)) out.tier = out.tier || '1080p';
    else if (/720p|_720_|\/720\//.test(sl)) out.tier = out.tier || '720p';
    else if (/540p|_540_|\/540\//.test(sl)) out.tier = out.tier || '540p';
    else if (/480p|_480_/.test(sl)) out.tier = out.tier || '480p';
    else if (/360p|_360_/.test(sl)) out.tier = out.tier || '360p';

    if (/bytevc1|hevc|h265/.test(sl)) out.codec = 'HEVC';
    else if (/h264|avc/.test(sl)) out.codec = 'H.264';

    const br = sl.match(/[?&]br=(\d+)/i) || sl.match(/bitrate[=:](\d+)/i);
    if (br) {
      out.bitrate = br[1];
      out.tier = out.tier || tierFromBitrate(br[1]);
    }

    if (!out.tier && out.w && out.h) out.tier = tierFromDimensions(out.w, out.h);
    if (!out.tier && out.w && !out.h) out.tier = tierFromDimensions(out.w, Math.round(out.w * 16 / 9));
    if (!out.tier && out.h && !out.w) out.tier = tierFromDimensions(Math.round(out.h * 9 / 16), out.h);

    return out;
  }

  function urlMatchesDecode(p, vw, vh) {
    if (!p.w || !p.h || !vw || !vh) return false;
    const tol = 0.22;
    return Math.abs(p.w - vw) / vw <= tol && Math.abs(p.h - vh) / vh <= tol;
  }

  function collectActiveVideoUrls(v) {
    const urls = [];
    const add = (u) => {
      if (u && typeof u === 'string' && u.length > 8 && !u.startsWith('blob:')) urls.push(u);
    };
    add(v.currentSrc);
    add(v.src);
    v.querySelectorAll('source').forEach((s) => add(s.src));
    return urls;
  }

  function analyzeVideoMedia(v) {
    const vw = v.videoWidth || 0;
    const vh = v.videoHeight || 0;

    // 1) Decoded stream = what's actually playing
    let w = vw;
    let h = vh;
    let tier = (vw && vh) ? tierFromDimensions(vw, vh) : null;

    // 2) TikTok UI label (studio / player quality picker)
    const uiTier = readQualityFromPage(v);
    if (uiTier && uiTier !== 'Auto') tier = uiTier;

    // 3) Only use CDN URL if it matches decoded size (ignore preloaded 1080p ladder)
    let codec = null;
    for (const url of collectActiveVideoUrls(v)) {
      const p = parseMediaUrl(url);
      if (p.codec) codec = p.codec;
      if (!vw || !vh) {
        if (p.w) w = p.w;
        if (p.h) h = p.h;
        if (p.tier) tier = p.tier;
        continue;
      }
      if (!urlMatchesDecode(p, vw, vh)) continue;
      if (p.tier) tier = p.tier;
    }

    if (!tier && codec) tier = codec;

    return {
      videoResolution: w && h ? w + '×' + h : '—',
      qualityTier: tier || '—',
    };
  }

  function parseFpsFromSrc(src) {
    if (!src) return null;
    const m = String(src).match(/fps[=:_-]?(\d{2,3})/i) || String(src).match(/(\d{2,3})fps/i);
    return m ? Number(m[1]) : null;
  }

  function getBufferAhead(v) {
    if (!v?.buffered?.length) return 0;
    const t = v.currentTime;
    for (let i = 0; i < v.buffered.length; i++) {
      const start = v.buffered.start(i);
      const end = v.buffered.end(i);
      if (t >= start && t <= end) return Math.max(0, end - t);
    }
    return 0;
  }

  function getState(v) {
    if (!v) return 'No video';
    if (v.error) return 'Error';
    if (v.ended) return 'Ended';
    if (v.seeking) return 'Seeking';
    if (v.paused) return 'Paused';
    if (v.readyState < 2) return 'Loading';
    if (v.readyState < 3) return 'Buffering';
    return 'Playing';
  }

  function estimateFps(v) {
    if (v.paused && cachedFps !== '—') return cachedFps;
    if (fpsSamples.length >= 4) {
      const avg = fpsSamples.reduce((a, b) => a + b, 0) / fpsSamples.length;
      if (avg >= 10 && avg <= 120) {
        cachedFps = String(Math.round(avg));
        return cachedFps;
      }
    }
    for (const u of collectActiveVideoUrls(v)) {
      const f = parseFpsFromSrc(u);
      if (f) {
        cachedFps = String(f);
        return cachedFps;
      }
    }
    return cachedFps;
  }

  function stopFpsTrack() {
    if (rvfHandle != null && trackedVideo?.cancelVideoFrameCallback) {
      try { trackedVideo.cancelVideoFrameCallback(rvfHandle); } catch (_) {}
    }
    rvfHandle = null;
    lastMediaTime = null;
  }

  function startFpsTrack(v) {
    if (v === trackedVideo) return;
    stopFpsTrack();
    trackedVideo = v;
    if (!v?.requestVideoFrameCallback || v.paused) return;

    const onFrame = (_now, meta) => {
      if (v !== trackedVideo || v.paused) return;
      if (lastMediaTime != null && meta.mediaTime > lastMediaTime) {
        const dt = meta.mediaTime - lastMediaTime;
        if (dt > 0.001 && dt < 0.2) {
          fpsSamples.push(1 / dt);
          if (fpsSamples.length > 20) fpsSamples.shift();
        }
      }
      lastMediaTime = meta.mediaTime;
      rvfHandle = v.requestVideoFrameCallback(onFrame);
    };
    rvfHandle = v.requestVideoFrameCallback(onFrame);
  }

  function isUsableVideo(v) {
    if (!v?.isConnected) return false;
    if (v.videoWidth > 0 && v.videoHeight > 0) return true;
    const r = v.getBoundingClientRect();
    return r.width >= 16 && r.height >= 16;
  }

  function isInViewport(v) {
    const r = v.getBoundingClientRect();
    return r.bottom > 0 && r.top < window.innerHeight &&
      r.right > 0 && r.left < window.innerWidth;
  }

  function pickNewLock() {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    let best = null;
    let bestScore = -1;

    for (const v of document.querySelectorAll('video')) {
      if (!isUsableVideo(v) || !isInViewport(v)) continue;
      const r = v.getBoundingClientRect();
      const center = cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom;
      let score = r.width * r.height;
      if (center) score *= 3;
      if (v === lockedVideo) score *= 2;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  }

  function resolveVideo() {
    if (lockedVideo?.isConnected && isUsableVideo(lockedVideo)) {
      lockLostAt = 0;
      return lockedVideo;
    }

    if (lockedVideo?.isConnected) {
      if (!lockLostAt) lockLostAt = Date.now();
      if (Date.now() - lockLostAt < LOCK_RELEASE_MS) return lockedVideo;
    }

    const candidate = pickNewLock();
    if (candidate) {
      if (candidate !== lockedVideo) {
        fpsSamples = [];
        cachedFps = '—';
      }
      lockedVideo = candidate;
      lockLostAt = 0;
      return lockedVideo;
    }

    if (lockedVideo && lockLostAt && Date.now() - lockLostAt < LOCK_RELEASE_MS) {
      return lockedVideo;
    }

    lockedVideo = null;
    lockLostAt = 0;
    return null;
  }

  function buildStats(v) {
    const media = analyzeVideoMedia(v);
    const rect = v.getBoundingClientRect();
    const buf = getBufferAhead(v);
    const currentSec = v.currentTime || 0;
    const durationSec = isFinite(v.duration) ? v.duration : 0;

    return {
      watching: true,
      videoResolution: media.videoResolution,
      screenResolution: Math.round(rect.width) + '×' + Math.round(rect.height),
      qualityTier: media.qualityTier,
      fps: estimateFps(v),
      time: formatTime(currentSec) + ' / ' + formatTime(durationSec),
      currentSec,
      durationSec,
      buffer: buf > 0 ? buf.toFixed(1) + 's' : '0s',
      state: getState(v),
      paused: !!v.paused,
    };
  }

  function emptyStats() {
    return {
      watching: false,
      videoResolution: '—',
      screenResolution: '—',
      qualityTier: '—',
      fps: '—',
      time: '—',
      currentSec: 0,
      durationSec: 0,
      buffer: '—',
      state: 'No video',
      paused: false,
    };
  }

  function staticKey(stats) {
    return [
      stats.videoResolution,
      stats.screenResolution,
      stats.qualityTier,
      stats.fps,
      stats.state,
      stats.buffer,
    ].join('|');
  }

  function collectStats() {
    const v = resolveVideo();
    if (!v) {
      stopFpsTrack();
      trackedVideo = null;
      if (lastPushed && lockLostAt && Date.now() - lockLostAt < 4000) {
        return { ...lastPushed, watching: true, paused: true, state: lastPushed.state };
      }
      return emptyStats();
    }

    startFpsTrack(v);
    return buildStats(v);
  }

  function shouldPush(stats) {
    if (!stats.watching) {
      return !lastPushed || lastPushed.watching;
    }
    const sk = staticKey(stats);
    if (sk !== lastStaticKey) return true;
    if (!lastPushed) return true;
    if (stats.state !== lastPushed.state) return true;
    if (stats.paused !== lastPushed.paused) return true;
    if (!stats.paused) {
      const t = Math.floor(stats.currentSec || 0);
      const lastT = Math.floor(lastPushed.currentSec || 0);
      if (t !== lastT) return true;
    }
    return false;
  }

  function pushStats() {
    const stats = collectStats();
    if (!shouldPush(stats)) return;
    lastStaticKey = stats.watching ? staticKey(stats) : '';
    lastPushed = { ...stats };
    chrome.runtime.sendMessage({ type: 'VIDEO_STATS_UPDATE', stats }).catch(() => {});
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'GET_VIDEO_STATS') {
      const s = collectStats();
      sendResponse(s.watching ? s : (lastPushed ? { ...lastPushed, watching: true } : s));
      return true;
    }
  });

  setInterval(pushStats, POLL_MS);

  document.addEventListener('pause', (e) => {
    if (e.target === lockedVideo) pushStats();
  }, true);
  document.addEventListener('play', (e) => {
    if (e.target === lockedVideo) pushStats();
  }, true);

  document.addEventListener('loadedmetadata', (e) => {
    if (e.target instanceof HTMLVideoElement && e.target === lockedVideo) pushStats();
  }, true);
  document.addEventListener('resize', () => {
    if (lockedVideo) pushStats();
  });

  pushStats();
})();
