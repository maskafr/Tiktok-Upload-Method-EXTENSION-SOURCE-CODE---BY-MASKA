# Legacy Method Testing Guide — v6+

## Overview

After testing 8 API-parameter variations, we've confirmed: **API parameters DO NOT affect TikTok's output resolution**. The server maintains a fixed compression profile (~7.5MB for aid=1988).

The old method likely worked because it matched TikTok's "trusted branch" — a fast-path that skipped certain processing steps or applied different compression rules based on file metadata and container structure.

This guide documents container-level attacks and experiments to re-trigger or work around that trusted branch.

---

## Why the Old Method Worked

**Hypothesis:** TikTok's ingest pipeline has multiple branches:

1. **"Trusted" fast-path** (old method hit this)
   - Recognizes file as clean, standard export
   - May skip aggressive compression
   - May honor higher resolutions
   - Triggered by: clean isom format, specific timescale, no FFmpeg trace, etc.

2. **"Web platform" path** (current, aid=1988)
   - Aggressive compression (1080→720)
   - Fixed output profile
   - May apply different rules to perceived "low-risk" uploads

3. **"Mobile app" path** (aid=1233, untested)
   - Possibly different codec/bitrate handling

4. **"High-res" path** (possibly exists)
   - 4K/2K might be handled differently
   - May bypass certain compression steps

---

## File-Level Modifications (FFmpeg Presets)

Before using extension methods, prepare your video with FFmpeg presets:

```bash
cd presets
tt-presets.bat [1-8] input_video.mp4
```

### Preset Guide

| # | Name | Method | Purpose | Expected Outcome |
|---|------|--------|---------|------------------|
| 1 | 4K Upscale | ffmpeg -vf scale=3840:2160 | Trigger 4K→1080 instead of 1080→720 | Keep better quality through initial downscale |
| 2 | 2K Upscale | ffmpeg -vf scale=2560:1440 | Intermediate test | Baseline between 4K and 1080p |
| 3 | HEVC/MOV | -c:v libx265 -movflags +faststart | Different codec = different pipeline | Access HEVC ingest branch |
| 4 | Fake HDR | -c:v libx264 -tag:v hvc1 (HDR tags) | HDR = priority processing? | Test if HDR triggers high-quality path |
| 5 | Ultra Bitrate | -b:v 50M (H.264 ultra-high) | Test if bitrate alone triggers quality | Check server recognition of source quality |
| 6 | Pre-720p60 | -vf scale=1280:720 -r 60 | Already output resolution | No downscaling needed by server |
| 7 | **Atom Patch** | -brand isom -movflags faststart | Metadata mismatch (720p claim, 1080p frames) | Test preflight vs. processing parser |
| 8 | **Combo** | 4K + HEVC + HDR tags | Maximum deviation from web upload | Ultimate test if any combination works |

---

## Container Metadata Methods (Extension)

All methods in the **Methods tab → Container Metadata** section:

### 1. **isom Brand (trusted branch)**
- **What it does:** Sets ftyp brand to 'isom' instead of 'isom'
- **Why:** Old method used isom brand. TikTok may recognize this as a standard export from trusted tools/CDNs.
- **How to use:** 
  - Prepare with FFmpeg: `ffmpeg -brand isom -movflags +faststart ...`
  - Enable in extension: toggle **isom Brand**
  - Upload with FFmpeg preset 1 or 7
- **Expected:** If isom brand alone re-triggers fast-path, output should improve

### 2. **Clean Metadata Signature**
- **What it does:** Removes FFmpeg encoder trace (©too/Lavf marker), preserves clean metadata
- **Why:** TikTok may fingerprint FFmpeg and apply different compression (like blacklisting FFmpeg exports after abuse)
- **How to use:**
  - Prepare with FFmpeg: `ffmpeg -c:v libx264 -c:a aac -movflags +faststart` (omit -metadata)
  - Enable: **Clean Metadata Signature**
  - Upload
- **Expected:** If encoder fingerprinting was the block, output should improve

### 3. **Dimension Mismatch (720 claim / 1080 frame)**
- **What it does:** Container metadata (tkhd/stsd) claims 720p, but bitstream is 1080p
- **Why:** Preflight may make decisions before decoding SPS. False 720p claim might pass preflight, while real 1080p frames go through processing unchanged.
- **How to use:**
  - Prepare: **FFmpeg preset 7** (atom patch)
  - Enable: **Dimension Mismatch**
  - Upload
- **Expected:** If preflight is separate from processing, you may pass as "safe 720p" while keeping 1080p quality

### 4. **Moov at Tail**
- **What it does:** Moves moov box to end of file (moov-at-end)
- **Why:** Some parsers read headers at file start, others normalize during processing. This tests if the two handlers disagree.
- **How to use:**
  - Prepare: `ffmpeg -movflags faststart,empty_moov ...` (creates empty moov at start, real moov at tail)
  - Enable: **Moov at Tail**
  - Upload
- **Expected:** If processing parser uses moov at tail differently, quality may improve

### 5. **Codec=HEVC (mov container)**
- **What it does:** Uses H.265 codec in MOV container (not MP4)
- **Why:** HEVC ingest may use a completely different pipeline than H.264. Different codec = different branching decision.
- **How to use:**
  - Prepare: **FFmpeg preset 3** (`ffmpeg -c:v libx265 -c:a aac -movflags +faststart output.mov`)
  - Enable: **Codec=HEVC**
  - Upload .mov file
- **Expected:** HEVC branch may not have the same compression rules as web H.264 path

### 6. **High-res Claim (4K container)**
- **What it does:** Container claims 2160p (4K), but actual bitstream is 1080p
- **Why:** Reverse test — maybe high-quality branch is triggered by declared resolution in metadata
- **How to use:**
  - Prepare: `ffmpeg -c:v libx264 [set tkhd/stsd to 2160x3840 via atom manipulation]`
  - Enable: **High-res Claim**
  - Upload
- **Expected:** If server trusts metadata declaration, it might apply 4K compression rules (less aggressive)

### 7. **Atom Structure (uuid tail)**
- **What it does:** Adds small uuid atom at file end
- **Why:** Specific atom structure might match "trusted exporter" profile. UUID tail is present in files from certain professional tools.
- **How to use:**
  - Prepare: `ffmpeg [insert small uuid after mdat]`
  - Enable: **Atom Structure**
  - Upload
- **Expected:** If structure matching exists, uuid may re-trigger trusted fast-path

### 8. **Timescale=90000**
- **What it does:** Sets video timescale to 90000 (MPEG standard)
- **Why:** Clean exports from professional tools use this timescale. FFmpeg defaults to different values. Matching clean signature.
- **How to use:**
  - Prepare: `ffmpeg -video_track_timescale 90000 ...`
  - Enable: **Timescale=90000**
  - Upload
- **Expected:** Standard timescale matches "clean export" fingerprint, may re-trigger trust

### 9-10. **Combined Dimension Tests**
- **1440p60 + 720 Claim:** Real 1440p, metadata claims 720p
- **4K60 + 1080 Claim:** Real 4K, metadata claims 1080p
- **Why:** Tests if you can trigger the high-quality branch (real bitstream) while passing "safe" metadata preflight (claimed dimensions)
- **How to use:**
  - Prepare: 1440p/4K encode with false metadata claims
  - Enable: corresponding method
  - Upload
- **Expected:** Best case — high-res quality while metadata appears "safe"

---

## Testing Strategy & Upload Order

**Phase 1: Encoder Signature (Presets 1-3)**
1. ✅ **Masked Encoder** (FFmpeg preset 1, clean metadata, isom brand)
   - Tests if removing FFmpeg fingerprint works
2. ✅ **Clean isom** (FFmpeg preset 7, isom brand enabled)
   - Tests if isom brand + clean metadata alone works
3. ⏳ **Dimension Mismatch** (FFmpeg preset 7, dimension mismatch enabled)
   - If preflight is separate, this might bypass compression

**Phase 2: Alternative Codecs (Preset 3)**
4. 🧪 **HEVC/MOV** (FFmpeg preset 3, useHEVC enabled)
   - Different codec = different pipeline

**Phase 3: Dimension Games (Presets 2, custom)**
5. 🧪 **1440p claim 720** (FFmpeg 1440p, res1440With720Claim enabled)
6. 🧪 **4K claim 1080** (FFmpeg 4K, res4kWith1080Claim enabled)
   - Tests if high-res can bypass compression while looking "safe"

**Phase 4: Advanced Atom Tricks (Custom FFmpeg)**
7. 🧪 **Moov at Tail** (FFmpeg with -movflags empty_moov, moovTail enabled)
8. 🧪 **UUID Atom** (Custom FFmpeg, uuidAtomTail enabled)

---

## Expected Outcomes & What They Mean

### ✅ Success Indicators
- Output remains **1080p** instead of 720p
- Output remains **≥12 MB** instead of 7.5 MB
- Output bitrate improves significantly
- Video quality is visibly sharper

### ❌ Failure Indicators
- Output still 720p / 7.5 MB
- Encoder fingerprinting made no difference
- All dimension mismatches still compress to 720p
- HEVC treated same as H.264

### 🔍 Inconclusive Cases
- Small quality improvement (±0.5 MB)
- Inconsistent results between uploads
  - → Try again (TikTok may batch-process, results lag)
  - → Check if server is performing A/B testing

---

## Common Issues & Fixes

### "Video still 720p even with all methods enabled"
**Diagnosis:** Server-side compression is not metadata-driven
- Try: HEVC codec (Phase 2), real 4K source (Phase 3)
- Note: May need to contact TikTok Creator Support if aid=1988 profile is hardcoded per account

### "1440p/4K uploads also compress to 720p"
**Diagnosis:** Resolution-agnostic compression; all Web uploads treated equally
- Try: Mobile app route (aid=1233 spoofing)
- Try: Different user agent (already included in presets)

### "Dimension mismatch didn't help"
**Diagnosis:** Preflight and processing both decode SPS independently
- Try: Moov at tail (parser inconsistency test)
- Try: UUID atom (if SPS is parsed, atom position shouldn't matter — if it helps, it was trust-based)

### "HEVC worked, but H.264 didn't"
**Diagnosis:** HEVC branch has different rules
- Stay on HEVC for uploads
- Note: Different audio codec support (AAC vs. others)
- Risk: May not work on all devices (iOS support)

---

## Reference: Old Method Profile (Confirmed Clean)

```
File: legacy_isom_comment_copy_1080p60.mp4

Container Atoms:
  ftyp: brand = isom, compatibility = isom/mp42
  moov: at file start (not tail)
    trak (video):
      handler: VideoHandler
      timescale: 90000
      width/height: 1080 x 1920
      codec: avc1 (H.264)
    trak (audio):
      handler: SoundHandler
      codec: mp4a (AAC)

Metadata:
  comment: Oxh6p4XQrdPdZtzNAsuV1g (preserved from old method)
  ©too: removed (no FFmpeg trace)

Bitstream:
  H.264 (Main Profile), 60 fps
  No encoder markers
  Clean SPS/PPS

Why This Worked:
  1. isom brand = trusted exporter
  2. Correct timescale (90000) = standard export
  3. No FFmpeg (©too) = not detected as suspicious
  4. Clean atom layout = not padded/modified
  5. Comment field = possibly whitelisted
```

---

## Monitoring Results

After each upload test:

1. **Status Tab**
   - Check transcode is called
   - Monitor final video resolution

2. **Sessions Tab**
   - Methods used should be listed
   - Check request count and publish status

3. **Log Tab**
   - Filter by CHUNK, PUBLISH categories
   - Check request/response sizes
   - Confirm transcode polling (if enabled)

---

## Next Steps (If All Methods Fail)

1. **Try original source in different format**
   - ProRes → H.264/MOV (professional format)
   - DNxHD → H.265/MOV (broadcast-grade)

2. **Reverse-engineer via Charles/Burp**
   - Capture a working upload from TikTok Creator Center
   - Compare container atoms vs. your FFmpeg output
   - Clone missing atoms/metadata

3. **Check account-level settings**
   - TikTok may have per-account compression profiles
   - Creator Center → Video uploads → check if there's a "quality tier" setting

4. **Coordinate with other sources**
   - If HEVC works but H.264 doesn't, report in matrix
   - If dimension tricks work on certain accounts but not others, it's user-based, not method-based

---

## Testing Matrix Template

```csv
Date,Preset,Method,Source_Res,Source_Size,Output_Res,Output_Size,Quality_Perceived,Notes
2026-05-20,1,isom_brand_clean,1080p,27MB,720p,7.5MB,bad,No change
2026-05-20,3,hevc_mov,1080p,25MB,1080p(?),?.?MB,good(?),Needs verification
2026-05-20,7,dimension_mismatch,1080p,27MB,720p,7.5MB,bad,Preflight decodes SPS
...
```

---

**End of Guide. Start testing Phase 1 — upload presets 1 and 7 with isom brand & clean metadata enabled.**
