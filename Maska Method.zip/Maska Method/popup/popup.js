(function () {
  'use strict';

  let config = null;
  const TAB_INDEX = { status: 0, methods: 1, sessions: 2 };

  document.addEventListener('DOMContentLoaded', async () => {
    if (window.self !== window.top) {
      document.documentElement.classList.add('in-page');
    }
    setupTabs();
    setupPowerLabel();
    await loadConfig();
    setupMethods();
    setupSessions();
    refreshStatus();
    setupVideoInfos();
    listenUpdates();
    moveNavIndicator(document.querySelector('.nav-btn.active'));
  });

  // ═══ TABS ═══
  function setupTabs() {
    const indicator = document.getElementById('navIndicator');
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        document.querySelectorAll('.nav-btn').forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });
        document.querySelectorAll('.panel').forEach(p => {
          p.classList.remove('active');
          p.style.animation = 'none';
        });
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        const panel = document.getElementById('tab-' + tab);
        panel.classList.add('active');
        void panel.offsetWidth;
        panel.style.animation = '';
        moveNavIndicator(btn);
        if (tab === 'status') refreshStatus();
        if (tab === 'sessions') refreshSessions();
      });
    });
  }

  function moveNavIndicator(activeBtn) {
    const indicator = document.getElementById('navIndicator');
    const idx = TAB_INDEX[activeBtn?.dataset.tab] ?? 0;
    indicator.style.transform = 'translateX(' + (idx * 100) + '%)';
  }

  function setupPowerLabel() {
    const toggle = document.getElementById('masterToggle');
    const label = document.getElementById('powerLabel');
    const sync = () => { label.textContent = toggle.checked ? 'ON' : 'OFF'; };
    toggle.addEventListener('change', sync);
    sync();
  }

  // ═══ CONFIG ═══
  async function loadConfig() {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'GET_CONFIG' });
      config = res.config;
      applyConfig();
    } catch (e) {}
  }

  function applyConfig() {
    if (!config) return;
    document.getElementById('masterToggle').checked = config.enabled;
    document.getElementById('powerLabel').textContent = config.enabled ? 'ON' : 'OFF';
    document.querySelectorAll('[data-method]').forEach(el => {
      if (config.methods?.[el.dataset.method] !== undefined) el.checked = config.methods[el.dataset.method];
    });
  }

  async function saveConfig() {
    if (!config) return;
    config.enabled = document.getElementById('masterToggle').checked;
    document.getElementById('powerLabel').textContent = config.enabled ? 'ON' : 'OFF';
    document.querySelectorAll('[data-method]').forEach(el => {
      config.methods[el.dataset.method] = el.checked;
    });
    await chrome.runtime.sendMessage({ type: 'SET_CONFIG', config });
  }

  // ═══ METHODS ═══
  function setupMethods() {
    document.querySelectorAll('[data-method]').forEach(el => {
      el.addEventListener('change', saveConfig);
    });
    document.getElementById('masterToggle').addEventListener('change', saveConfig);
  }

  // ═══ STATUS ═══
  async function refreshStatus() {
    try {
      const [logRes, sessRes] = await Promise.all([
        chrome.runtime.sendMessage({ type: 'GET_LOG', filter: { limit: 500 } }),
        chrome.runtime.sendMessage({ type: 'GET_SESSIONS' }),
      ]);

      const log = logRes.log || [];
      const active = sessRes.active;

      setSignal('statusEnabled', config?.enabled ? 'ok' : 'err',
        config?.enabled ? 'Live' : 'Off');

      const vidEntry = [...log].reverse().find(e => e.cat === 'COPYRIGHT' || e.cat === 'TRANSCODE_ON');
      const vidMatch = vidEntry?.url?.match(/video_id=(v[0-9a-z]+)/i);
      if (active?.videoId) {
        setSignal('statusVideoId', 'ok', active.videoId);
      } else if (vidMatch) {
        setSignal('statusVideoId', 'warn', vidMatch[1]);
      } else {
        setSignal('statusVideoId', 'err', 'Waiting…');
      }

      const transcodeLog = log.filter(e => e.cat === 'TRANSCODE_ON' || e.cat === 'TRANSCODE_POLL');
      if (transcodeLog.length > 0) {
        setSignal('statusTranscode', 'ok', 'Active');
      } else if (active?.transcodeEnabled) {
        setSignal('statusTranscode', 'ok', 'Ready');
      } else {
        setSignal('statusTranscode', 'err', 'Idle');
      }

      const pubLog = log.filter(e => e.cat === 'PUBLISH');
      if (pubLog.length > 0) {
        setSignal('statusPublish', 'ok', pubLog.length + ' sent');
      } else {
        setSignal('statusPublish', 'warn', 'Pending');
      }
    } catch (e) {}
  }

  function setSignal(baseId, state, text) {
    const ring = document.getElementById(baseId + 'Ring');
    const value = document.getElementById(baseId + 'Text');
    if (ring) {
      ring.className = 'signal-ring state-' + state;
    }
    if (value) {
      value.textContent = text;
      value.classList.add('flash');
      setTimeout(() => value.classList.remove('flash'), 400);
    }
  }

  // ═══ SESSIONS ═══
  function setupSessions() {
    document.getElementById('btnSessionsRefresh')?.addEventListener('click', () => {
      const btn = document.getElementById('btnSessionsRefresh');
      btn?.classList.add('spin');
      refreshSessions().finally(() => setTimeout(() => btn?.classList.remove('spin'), 500));
    });
    document.getElementById('btnSessionsClear')?.addEventListener('click', async () => {
      if (confirm('Clear all Maska Method sessions?')) {
        await chrome.runtime.sendMessage({ type: 'CLEAR_SESSIONS' });
        refreshSessions();
      }
    });
    document.getElementById('btnExport')?.addEventListener('click', async () => {
      const res = await chrome.runtime.sendMessage({ type: 'EXPORT' });
      dl(res.data, 'maska-method-export.json');
    });
  }

  async function refreshSessions() {
    const list = document.getElementById('sessionsList');
    if (!list) return;
    try {
      const res = await chrome.runtime.sendMessage({ type: 'GET_SESSIONS' });
      const all = res.sessions || [];
      if (res.active) all.push(res.active);
      if (all.length === 0) {
        list.innerHTML =
          '<div class="empty-state">' +
            '<div class="empty-orbit"></div>' +
            '<p>No runs yet</p>' +
            '<span>Upload on TikTok — a session logs automatically</span>' +
          '</div>';
        return;
      }
      list.innerHTML = '';
      for (let i = all.length - 1; i >= 0; i--) {
        list.appendChild(makeRunCard(all[i], all.length - 1 - i));
      }
    } catch (e) {
      list.innerHTML = '<div class="empty-state"><p>Error</p><span>Could not load sessions</span></div>';
    }
  }

  function makeRunCard(s, staggerIdx) {
    const div = document.createElement('article');
    div.className = 'run-card';
    div.style.animationDelay = (staggerIdx * 0.06) + 's';
    const tags = (s.methodsUsed || []).map(m => '<span class="run-tag">' + esc(m) + '</span>').join('');
    const events = (s.events || []).map(e => {
      const t = new Date(e.t).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      return '[' + t + '] ' + e.type + (e.detail ? ': ' + String(e.detail).slice(0, 120) : '');
    }).join('\n');

    const st = s.status || 'active';
    div.innerHTML =
      '<div class="run-head">' +
        '<span class="run-id">Run #' + s.id + '</span>' +
        '<span class="run-badge ' + esc(st) + '">' + esc(st) + '</span>' +
      '</div>' +
      '<div class="run-meta">' +
        (s.startTime ? '<div>Started <strong>' + new Date(s.startTime).toLocaleString('en') + '</strong></div>' : '') +
        (s.videoId ? '<div>ID <strong>' + esc(s.videoId) + '</strong></div>' : '') +
        '<div>60fps <strong>' + (s.transcodeEnabled ? 'yes' : 'no') + '</strong></div>' +
        '<div>Publish <strong>' + (s.publishModified ? 'modified' : 'default') + '</strong></div>' +
      '</div>' +
      (tags ? '<div class="run-tags">' + tags + '</div>' : '') +
      '<pre class="run-log">' + esc(events || 'No events') + '</pre>';

    div.addEventListener('click', () => div.classList.toggle('open'));
    return div;
  }

  // ═══ VIDEO INFOS ═══
  const VI_FIELDS = [
    ['viVideoRes', 'videoResolution'],
    ['viScreenRes', 'screenResolution'],
    ['viQuality', 'qualityTier'],
    ['viFps', 'fps'],
    ['viTime', 'time'],
    ['viBuffer', 'buffer'],
    ['viState', 'state'],
  ];

  let viSnapshot = null;
  let viLastStateClass = '';
  const viDisplayed = {};

  function formatViTime(sec, dur) {
    const f = (n) => {
      if (!isFinite(n) || n < 0) return '0:00';
      const m = Math.floor(n / 60);
      const s = Math.floor(n % 60);
      return m + ':' + String(s).padStart(2, '0');
    };
    return f(sec) + ' / ' + f(dur);
  }

  function setViField(elId, val) {
    if (viDisplayed[elId] === val) return;
    viDisplayed[elId] = val;
    const el = document.getElementById(elId);
    if (el) el.textContent = val;
  }

  function renderVideoInfos(stats) {
    const block = document.getElementById('videoInfosBlock');
    if (!block || !stats) return;

    const snap = stats.watching ? stats : viSnapshot;
    if (!snap) return;

    if (stats.watching) viSnapshot = { ...stats };

    block.classList.add('is-live');

    const stateKey = (snap.state || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (stateKey && stateKey !== viLastStateClass) {
      if (viLastStateClass) block.classList.remove('state-' + viLastStateClass);
      block.classList.add('state-' + stateKey);
      viLastStateClass = stateKey;
    }

    for (const [elId, key] of VI_FIELDS) {
      setViField(elId, snap[key] ?? '—');
    }
    setViField('viTime', snap.time ?? formatViTime(snap.currentSec, snap.durationSec));
  }

  function applyVideoStats(stats) {
    if (!stats) return;
    if (stats.watching) {
      renderVideoInfos(stats);
      return;
    }
    if (viSnapshot) renderVideoInfos(viSnapshot);
  }

  function setupVideoInfos() {
    const block = document.getElementById('videoInfosBlock');
    if (block) block.classList.add('is-live');
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_VIDEO_STATS' })
        .then((stats) => { if (stats) applyVideoStats(stats); })
        .catch(() => {});
    }, 400);
  }

  // ═══ LIVE UPDATES ═══
  function listenUpdates() {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === 'VIDEO_STATS_UPDATE' && msg.stats) {
        applyVideoStats(msg.stats);
        return;
      }
      if (msg.type === 'VIDEO_ID_DETECTED' || msg.type === 'TRANSCODE_UPDATE' || msg.type === 'PUBLISH_UPDATE') {
        const statusTab = document.querySelector('.nav-btn[data-tab="status"]');
        if (statusTab?.classList.contains('active')) refreshStatus();
      }
    });
  }

  // ═══ UTILS ═══
  function esc(s) {
    if (!s) return '';
    const d = document.createElement('div');
    d.textContent = String(s);
    return d.innerHTML;
  }
  function dl(data, name) {
    const b = new Blob([data], { type: 'application/json' });
    const u = URL.createObjectURL(b);
    const a = document.createElement('a');
    a.href = u;
    a.download = name;
    a.click();
    URL.revokeObjectURL(u);
  }
})();
