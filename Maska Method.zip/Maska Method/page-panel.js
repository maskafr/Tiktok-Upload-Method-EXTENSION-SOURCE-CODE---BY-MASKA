/**
 * Maska Method — in-page panel on all TikTok pages
 */
(function () {
  'use strict';

  const HOST_ID = 'maska-method-host';
  const PANEL_URL = chrome.runtime.getURL('popup/popup.html');
  const ICON_URL = chrome.runtime.getURL('icons/icon48.png');
  const STORAGE_KEY = 'panelCollapsed';
  const POS_KEY = 'panelPosition';
  const PANEL_W = 380;
  const PANEL_H = 580;
  const FAB_SIZE = 48;
  const MARGIN = 8;

  const HOST_CSS = `
    :host { all: initial; }
    .maska-shell {
      position: fixed;
      left: 0;
      top: 0;
      z-index: 2147483647;
      font-family: system-ui, sans-serif;
      pointer-events: none;
    }
    .maska-shell.is-dragging {
      user-select: none;
    }
    .maska-shell.is-dragging .maska-iframe {
      pointer-events: none;
    }
    .maska-shell * { pointer-events: auto; box-sizing: border-box; }
    .maska-panel {
      width: 380px;
      height: 580px;
      display: flex;
      flex-direction: column;
      border-radius: 18px;
      overflow: hidden;
      background: #07060d;
      box-shadow:
        0 0 0 1px rgba(192, 132, 252, 0.25),
        0 24px 80px rgba(0, 0, 0, 0.55),
        0 0 40px rgba(124, 58, 237, 0.15);
      animation: maskaIn 0.45s cubic-bezier(0.22, 1, 0.36, 1) both;
    }
    @keyframes maskaIn {
      from { opacity: 0; transform: translateY(-12px) scale(0.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .maska-panel-bar {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 12px;
      background: linear-gradient(90deg, rgba(124,58,237,0.35), rgba(6,182,212,0.12));
      border-bottom: 1px solid rgba(255,255,255,0.08);
      cursor: grab;
      touch-action: none;
    }
    .maska-shell.is-dragging .maska-panel-bar {
      cursor: grabbing;
    }
    .maska-drag-hint {
      flex: 1;
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 0;
    }
    .maska-drag-grip {
      width: 14px;
      height: 14px;
      opacity: 0.45;
      background:
        radial-gradient(circle, #e9d5ff 1.5px, transparent 1.5px) 0 0 / 7px 7px;
    }
    .maska-panel-title {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: #e9d5ff;
      white-space: nowrap;
    }
    .maska-discord {
      font-size: 9px;
      font-weight: 600;
      color: #67e8f9;
      text-decoration: none;
      letter-spacing: 0.02em;
      white-space: nowrap;
      margin-right: 4px;
      opacity: 0.9;
    }
    .maska-discord:hover { color: #e9d5ff; }
    .maska-btn-min {
      width: 28px;
      height: 28px;
      flex-shrink: 0;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 8px;
      background: rgba(0,0,0,0.35);
      color: #f4f0ff;
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      transition: transform 0.2s, background 0.2s;
    }
    .maska-btn-min:hover {
      transform: scale(1.08);
      background: rgba(192,132,252,0.25);
    }
    .maska-iframe {
      flex: 1;
      width: 100%;
      min-height: 0;
      border: none;
      display: block;
      background: #07060d;
    }
    .maska-fab {
      display: none;
      width: 48px;
      height: 48px;
      border: none;
      border-radius: 14px;
      cursor: grab;
      touch-action: none;
      background: linear-gradient(135deg, #7c3aed, #06b6d4);
      box-shadow: 0 8px 28px rgba(124, 58, 237, 0.45);
      animation: maskaFab 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) both;
    }
    .maska-shell.is-dragging .maska-fab {
      cursor: grabbing;
    }
    @keyframes maskaFab {
      from { opacity: 0; transform: scale(0.5); }
      to { opacity: 1; transform: scale(1); }
    }
    .maska-fab-icon {
      width: 32px;
      height: 32px;
      border-radius: 10px;
      display: block;
      pointer-events: none;
    }
    .maska-shell.is-collapsed .maska-panel { display: none; }
    .maska-shell.is-collapsed .maska-fab { display: grid; place-items: center; }
    @media (prefers-reduced-motion: reduce) {
      .maska-panel, .maska-fab { animation: none !important; }
    }
  `;

  let host = null;
  let collapsed = false;

  function defaultPosition() {
    return {
      x: Math.max(MARGIN, window.innerWidth - PANEL_W - 14),
      y: 14,
    };
  }

  function clampPosition(x, y, w, h) {
    const maxX = Math.max(MARGIN, window.innerWidth - w - MARGIN);
    const maxY = Math.max(MARGIN, window.innerHeight - h - MARGIN);
    return {
      x: Math.min(maxX, Math.max(MARGIN, x)),
      y: Math.min(maxY, Math.max(MARGIN, y)),
    };
  }

  function applyPosition(shell, x, y) {
    const w = collapsed ? FAB_SIZE : PANEL_W;
    const h = collapsed ? FAB_SIZE : PANEL_H;
    const p = clampPosition(x, y, w, h);
    shell.style.left = p.x + 'px';
    shell.style.top = p.y + 'px';
    return p;
  }

  function savePosition(shell) {
    const x = parseFloat(shell.style.left) || 0;
    const y = parseFloat(shell.style.top) || 0;
    chrome.storage.local.set({ [POS_KEY]: { x, y } }).catch(() => {});
  }

  function setupDrag(shell, handles, opts) {
    let dragging = false;
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let origX = 0;
    let origY = 0;
    let moved = false;

    const onPointerDown = (e) => {
      if (opts?.ignore?.(e.target)) return;
      if (e.button !== 0) return;
      dragging = true;
      moved = false;
      pointerId = e.pointerId;
      startX = e.clientX;
      startY = e.clientY;
      origX = parseFloat(shell.style.left) || 0;
      origY = parseFloat(shell.style.top) || 0;
      shell.classList.add('is-dragging');
      try { e.currentTarget.setPointerCapture(pointerId); } catch (_) {}
      e.preventDefault();
    };

    const onPointerMove = (e) => {
      if (!dragging || e.pointerId !== pointerId) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved = true;
      applyPosition(shell, origX + dx, origY + dy);
    };

    const endDrag = (e) => {
      if (!dragging || (e.pointerId != null && e.pointerId !== pointerId)) return;
      dragging = false;
      shell.classList.remove('is-dragging');
      document.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('pointerup', endDrag);
      document.removeEventListener('pointercancel', endDrag);
      savePosition(shell);
      pointerId = null;
    };

    handles.forEach((el) => {
      el.addEventListener('pointerdown', (e) => {
        onPointerDown(e);
        document.addEventListener('pointermove', onPointerMove);
        document.addEventListener('pointerup', endDrag);
        document.addEventListener('pointercancel', endDrag);
      });
      el.addEventListener('click', (e) => {
        if (moved) {
          e.preventDefault();
          e.stopPropagation();
          moved = false;
        }
      }, true);
    });

    window.addEventListener('resize', () => {
      const x = parseFloat(shell.style.left) || 0;
      const y = parseFloat(shell.style.top) || 0;
      applyPosition(shell, x, y);
    });
  }

  function inject() {
    if (host || !document.body) return;
    if (window !== window.top) return;

    host = document.createElement('div');
    host.id = HOST_ID;
    host.setAttribute('data-maska-panel', '1');

    const shadow = host.attachShadow({ mode: 'open' });
    shadow.innerHTML =
      '<style>' + HOST_CSS + '</style>' +
      '<div class="maska-shell">' +
        '<button type="button" class="maska-fab" title="Open Maska Method">' +
          '<img class="maska-fab-icon" src="' + ICON_URL + '" alt="Maska Method" width="32" height="32">' +
        '</button>' +
        '<div class="maska-panel">' +
          '<div class="maska-panel-bar" title="Drag to move">' +
            '<div class="maska-drag-hint">' +
              '<span class="maska-drag-grip" aria-hidden="true"></span>' +
              '<span class="maska-panel-title">Maska Method</span>' +
            '</div>' +
            '<a class="maska-discord" href="https://discord.gg/maska" target="_blank" rel="noopener noreferrer">discord.gg/maska</a>' +
            '<button type="button" class="maska-btn-min" title="Minimize">−</button>' +
          '</div>' +
          '<iframe class="maska-iframe" src="' + PANEL_URL + '" allow="clipboard-read; clipboard-write"></iframe>' +
        '</div>' +
      '</div>';

    const shell = shadow.querySelector('.maska-shell');
    const fab = shadow.querySelector('.maska-fab');
    const panelBar = shadow.querySelector('.maska-panel-bar');
    const btnMin = shadow.querySelector('.maska-btn-min');

    fab.addEventListener('click', () => setCollapsed(false));
    btnMin.addEventListener('click', () => setCollapsed(true));

    function setCollapsed(value) {
      collapsed = value;
      shell.classList.toggle('is-collapsed', collapsed);
      const x = parseFloat(shell.style.left) || 0;
      const y = parseFloat(shell.style.top) || 0;
      applyPosition(shell, x, y);
      chrome.storage.local.set({ [STORAGE_KEY]: collapsed }).catch(() => {});
    }

    setupDrag(shell, [panelBar, fab], {
      ignore: (target) => !!target.closest('.maska-btn-min, .maska-discord'),
    });

    chrome.storage.local.get([STORAGE_KEY, POS_KEY], (data) => {
      const pos = data[POS_KEY];
      const def = defaultPosition();
      const x = typeof pos?.x === 'number' ? pos.x : def.x;
      const y = typeof pos?.y === 'number' ? pos.y : def.y;
      if (data[STORAGE_KEY] === true) setCollapsed(true);
      else setCollapsed(false);
      applyPosition(shell, x, y);
    });

    host._maskaSetCollapsed = setCollapsed;
    document.documentElement.appendChild(host);
  }

  function toggle() {
    if (!host?._maskaSetCollapsed) {
      inject();
      return { visible: true };
    }
    collapsed = !collapsed;
    host._maskaSetCollapsed(collapsed);
    return { visible: !collapsed };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'TOGGLE_PANEL') {
      sendResponse(toggle());
      return true;
    }
    if (msg.type === 'SHOW_PANEL') {
      inject();
      host?._maskaSetCollapsed?.(false);
      sendResponse({ visible: true });
      return true;
    }
    if (msg.type === 'PANEL_PING') {
      sendResponse({ mounted: !!host });
      return true;
    }
  });

  function boot() {
    if (document.body) inject();
    else document.addEventListener('DOMContentLoaded', inject, { once: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
