/**
 * TT Analytics — Interceptor (v6)
 *
 * Injected into PAGE CONTEXT to intercept fetch/XHR.
 *
 * v6 NEW:
 *  1. spoofAid: replace aid=1988 → 1233 (mobile app ID) in URL
 *  2. FFmpeg presets for video pre-processing before upload
 *  3. 8 tests confirmed: API parameters DO NOT affect 720p
 *  4. New strategy: change the file itself + aid spoofing
 *
 * RESULTS FROM 8 TESTS:
 *  - cloud_edit_video_height: NO EFFECT (tests 1-8)
 *  - hd_video/allow_hd/quality_type: NO EFFECT (test 8)
 *  - device_platform=android: NO EFFECT (test 8)
 *  - spoofMobileUA: NO EFFECT (test 8)
 *  - forceVideoCanvas: NO EFFECT (test 8)
 *  - transcode/enable: WORKS for 60fps
 *  - privateFirst: WORKS for compression bypass on publish
 */

(function () {
  'use strict';

  let config = null;
  let configReady = false;

  const FALLBACK_CONFIG = {
    enabled: true,
    methods: {
      transcodeEnable: true,
      modifyPublishBody: true,
      privateFirst: true,
      modifyCloudEdit: false,
      modifyEntryPoint: false,
      modifySinglePostInfo: false,
      removeDraft: true,
      removeCloudEdit: true,
      spoofDevicePlatform: false,
      addHDParams: false,
      forceVideoCanvas: false,
      spoofAid: false,
      pollTranscode: false,
    },
    params: {
      cloudEditHeight: 1080,
      cloudEditWidth: 1080,
      enterPostPageFrom: 2,
      singlePostHeight: 0,
      singlePostWidth: 0,
    },
  };

  // ═══ CONFIG ═══

  function requestConfig() {
    window.postMessage({ dir: 'TT_TO_BG', msg: { type: 'GET_CONFIG' } }, '*');
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.dir !== 'TT_FROM_BG') return;
    const msg = e.data.msg;
    if (msg?.type === 'CONFIG' && msg.config) {
      config = msg.config;
      configReady = true;
    }
  });

  requestConfig();
  let configAttempts = 0;
  const configTimer = setInterval(() => {
    if (configReady) {
      clearInterval(configTimer);
      return;
    }
    if (configAttempts++ > 40) {
      clearInterval(configTimer);
      return;
    }
    requestConfig();
  }, 200);

  function getConfig() {
    return config || FALLBACK_CONFIG;
  }

  function hasRealConfig() {
    return configReady && !!config;
  }

  function toBg(msg) {
    window.postMessage({ dir: 'TT_TO_BG', msg }, '*');
  }

  // ═══ FILE_KEY DETECTOR ═══

  function detectFileKey(url, body) {
    if (!url.includes('transcode/result')) return;
    if (!body) return;
    let text = body;
    if (typeof body !== 'string') {
      try {
        if (body instanceof ArrayBuffer || body instanceof Uint8Array) {
          text = new TextDecoder('utf-8').decode(body);
        } else {
          return;
        }
      } catch (e) { return; }
    }
    try {
      const data = JSON.parse(text);
      if (data.video_info && Array.isArray(data.video_info)) {
        for (const vi of data.video_info) {
          if (vi.file_key && vi.file_key.startsWith('file_')) {
            console.log('[TT-int] 🔑 file_key found:', vi.file_key);
            toBg({
              type: 'FILE_KEY_FROM_PAGE',
              fileKey: vi.file_key,
              duration: vi.original_duration_ms || 0
            });
          }
        }
      }
    } catch (e) { /* not JSON — OK */ }
  }

  // ═══ VIDEO_ID DETECTOR ═══

  const seenIds = new Set();

  function detectVideoId(url, body) {
    // Из URL
    const m1 = url.match(/video_id=(v[0-9a-z]+)/i);
    if (m1 && !seenIds.has(m1[1])) {
      seenIds.add(m1[1]);
      toBg({ type: 'VIDEO_ID_FROM_PAGE', videoId: m1[1] });
    }

    // Из тела запроса
    if (body && typeof body === 'string') {
      const m2 = body.match(/"video_id"\s*:\s*"(v[0-9a-z]+)"/i);
      if (m2 && !seenIds.has(m2[1])) {
        seenIds.add(m2[1]);
        toBg({ type: 'VIDEO_ID_FROM_PAGE', videoId: m2[1] });
      }
    }
  }

  // ═══ URL SPOOFING ═══

  function spoofUrl(url) {
    const cfg = getConfig();
    if (!cfg.enabled) return url;

    const wantPlatform = cfg.methods?.spoofDevicePlatform;
    const wantAid = cfg.methods?.spoofAid;
    if (!wantPlatform && !wantAid) return url;

    // Only for key APIs
    const isKeyApi = url.includes('transcode/') ||
                     url.includes('project/post') ||
                     url.includes('tiktokcdn.com/upload') ||
                     url.includes('ApplyUploadInner') ||
                     url.includes('CommitUploadInner');
    if (!isKeyApi) return url;

    let newUrl = url;

    // device_platform=web → device_platform=android
    if (wantPlatform) {
      if (url.includes('device_platform=web')) {
        newUrl = newUrl.replace(/device_platform=web_pc/g, 'device_platform=android');
        newUrl = newUrl.replace(/device_platform=web/g, 'device_platform=android');
      } else if (!url.includes('device_platform=') && url.includes('?')) {
        newUrl += '&device_platform=android';
      }
    }

    // aid=1988 → aid=1233 (TikTok mobile app ID)
    if (wantAid && newUrl.includes('aid=1988')) {
      newUrl = newUrl.replace(/aid=1988/g, 'aid=1233');
    }

    if (newUrl !== url) {
      const changes = [];
      if (wantPlatform && newUrl.includes('device_platform=android')) changes.push('platform→android');
      if (wantAid && newUrl.includes('aid=1233')) changes.push('aid→1233');
      console.log('[TT-int] 📱 URL spoofed:', changes.join(', '));
    }
    return newUrl;
  }

  // ═══ MODIFY PUBLISH BODY ═══

  function modifyPublishBody(url, body) {
    if (!url.includes('project/post')) return body;

    const cfg = getConfig();
    if (!cfg.enabled || !cfg.methods?.modifyPublishBody) {
      toBg({ type: 'PUBLISH_INTERCEPTED', modified: false, changes: [], usedFallback: !hasRealConfig() });
      return body;
    }

    try {
      let data;
      if (typeof body === 'string') {
        data = JSON.parse(body);
      } else {
        return body;
      }

      let modified = false;
      const changes = [];

      // 1. cloud_edit in vedit_common_info (KEY PARAMETER)
      if (cfg.methods.modifyCloudEdit) {
        const features = data.feature_common_info_list;
        if (features && Array.isArray(features)) {
          for (const f of features) {
            if (f.vedit_common_info) {
              f.vedit_common_info.cloud_edit_video_height = cfg.params.cloudEditHeight;
              f.vedit_common_info.cloud_edit_video_width = cfg.params.cloudEditWidth;
              modified = true;
              changes.push('vedit.cloud_edit=' + cfg.params.cloudEditHeight + 'x' + cfg.params.cloudEditWidth);
            }
          }
        }
      }

      // 2. cloud_edit in single_post_feature_info (OPTIONAL)
      if (cfg.methods.modifySinglePostInfo) {
        const posts = data.single_post_req_list;
        if (posts && Array.isArray(posts)) {
          for (const p of posts) {
            if (p.single_post_feature_info) {
              const h = cfg.params.singlePostHeight || cfg.params.cloudEditHeight;
              const w = cfg.params.singlePostWidth || cfg.params.cloudEditWidth;
              p.single_post_feature_info.cloud_edit_video_height = h;
              p.single_post_feature_info.cloud_edit_video_width = w;
              modified = true;
              changes.push('spf.cloud_edit=' + h + 'x' + w);
            }
          }
        }
      }

      // 3. enter_post_page_from
      if (cfg.methods.modifyEntryPoint && data.post_common_info) {
        const old = data.post_common_info.enter_post_page_from;
        data.post_common_info.enter_post_page_from = cfg.params.enterPostPageFrom;
        if (old !== cfg.params.enterPostPageFrom) {
          modified = true;
          changes.push('entry=' + old + '→' + cfg.params.enterPostPageFrom);
        }
      }

      // 4. privateFirst: visibility_type
      if (cfg.methods.privateFirst) {
        const features = data.feature_common_info_list;
        if (features && Array.isArray(features)) {
          for (const f of features) {
            if (f.privacy_setting_info && f.privacy_setting_info.visibility_type !== undefined) {
              const old = f.privacy_setting_info.visibility_type;
              f.privacy_setting_info.visibility_type = 1;
              if (old !== 1) {
                modified = true;
                changes.push('visibility=' + old + '→1(private)');
              }
            }
          }
        }
      }

      // 5. removeDraft: remove draft field from vedit_common_info
      if (cfg.methods.removeDraft) {
        const features = data.feature_common_info_list;
        if (features && Array.isArray(features)) {
          for (const f of features) {
            if (f.vedit_common_info && 'draft' in f.vedit_common_info) {
              delete f.vedit_common_info.draft;
              modified = true;
              changes.push('draft=REMOVED');
            }
          }
        }
      }

      // 6. removeCloudEdit: remove cloud_edit fields completely (test — let TikTok decide)
      if (cfg.methods.removeCloudEdit) {
        const features = data.feature_common_info_list;
        if (features && Array.isArray(features)) {
          for (const f of features) {
            if (f.vedit_common_info) {
              delete f.vedit_common_info.cloud_edit_video_height;
              delete f.vedit_common_info.cloud_edit_video_width;
              modified = true;
              changes.push('vedit.cloud_edit=REMOVED');
            }
          }
        }
        const posts = data.single_post_req_list;
        if (posts && Array.isArray(posts)) {
          for (const p of posts) {
            if (p.single_post_feature_info) {
              delete p.single_post_feature_info.cloud_edit_video_height;
              delete p.single_post_feature_info.cloud_edit_video_width;
              modified = true;
              changes.push('spf.cloud_edit=REMOVED');
            }
          }
        }
      }

      // 7. forceVideoCanvas: set cloud_edit_is_use_video_canvas=true
      if (cfg.methods.forceVideoCanvas) {
        const posts = data.single_post_req_list;
        if (posts && Array.isArray(posts)) {
          for (const p of posts) {
            if (p.single_post_feature_info) {
              p.single_post_feature_info.cloud_edit_is_use_video_canvas = true;
              modified = true;
              changes.push('canvas=true');
            }
          }
        }
      }

      // 8. addHDParams: mobile HD parameters
      if (cfg.methods.addHDParams) {
        // Add to single_post_req_list
        const posts = data.single_post_req_list;
        if (posts && Array.isArray(posts)) {
          for (const p of posts) {
            // allow_download — mobile parameter for HD
            p.allow_download = 1;
            // is_long_video = 1 — may trigger different encoding profile
            p.is_long_video = 1;
            modified = true;
            changes.push('allow_download=1,is_long_video=1');

            if (p.single_post_feature_info) {
              // Set HD-related parameters
              p.single_post_feature_info.hd_video = 1;
              p.single_post_feature_info.allow_hd = true;
              p.single_post_feature_info.quality_type = 2;
              changes.push('hd_video=1,allow_hd=true,quality_type=2');
            }
          }
        }

        // Also add to post_common_info
        if (data.post_common_info) {
          data.post_common_info.hd_video = 1;
          data.post_common_info.allow_hd = true;
          changes.push('common.hd=1');
        }
      }

      if (modified) {
        console.log('[Maska-int] Publish body modified:', changes.join(', '));
      }

      // Report to background
      toBg({
        type: 'PUBLISH_INTERCEPTED',
        modified,
        changes,
        usedFallback: !hasRealConfig(),
        body: JSON.stringify(data).slice(0, 2000)
      });

      return JSON.stringify(data);
    } catch (e) {
      console.warn('[TT-int] Error modifying publish:', e);
      toBg({ type: 'PUBLISH_INTERCEPTED', modified: false, error: e.message });
      return body;
    }
  }

  // ═══ FETCH INTERCEPTION ═══

  const _fetch = window.fetch;
  window.fetch = async function (...args) {
    let [input, init] = args;
    let url = typeof input === 'string' ? input : (input?.url || '');

    // Пропускаем не-TikTok
    if (!url.includes('tiktok.com') && !url.includes('tiktokcdn.com')) {
      return _fetch.apply(this, args);
    }

    // Детектим video_id
    detectVideoId(url, init?.body && typeof init.body === 'string' ? init.body : null);

    // Детектим file_key из нативного transcode/result
    detectFileKey(url, init?.body && typeof init.body === 'string' ? init.body : null);

    // === v5: СПУФИНГ URL (device_platform) ===
    const spoofedUrl = spoofUrl(url);
    if (spoofedUrl !== url) {
      if (typeof input === 'string') {
        input = spoofedUrl;
      } else if (input?.url) {
        input = new Request(spoofedUrl, input);
      }
      url = spoofedUrl;
    }

    // Модифицируем publish body
    if (init?.body && typeof init.body === 'string' && url.includes('project/post')) {
      if (!init) init = {};
      init.body = modifyPublishBody(url, init.body);
    }

    try {
      const response = await _fetch.call(this, input, init);
      const clone = response.clone();

      // Log asynchronously
      (async () => {
        try {
          const ct = clone.headers.get('content-type') || '';
          let resBody = null;
          if (ct.includes('json') || ct.includes('text')) {
            resBody = await clone.text();
          }

          // Look for video_id in response too
          if (resBody) detectVideoId(url, resBody);

          toBg({
            type: 'INTERCEPTED_DATA',
            data: {
              url, method: init?.method || 'GET', ts: Date.now(),
              reqBody: init?.body && typeof init.body === 'string' ? init.body.slice(0, 5000) : null,
              resBody: resBody ? resBody.slice(0, 5000) : null,
              status: response.status,
            }
          });
        } catch (e) {}
      })();

      return response;
    } catch (e) { throw e; }
  };

  // ═══ XHR INTERCEPTION ═══

  const _xhrOpen = XMLHttpRequest.prototype.open;
  const _xhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ttUrl = url;
    this._ttMethod = method;
    // === v5: URL SPOOFING ===
    const spoofedUrl = spoofUrl(url);
    if (spoofedUrl !== url) {
      this._ttUrl = spoofedUrl;
      return _xhrOpen.call(this, method, spoofedUrl, ...rest);
    }
    return _xhrOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const url = this._ttUrl || '';

    if (url.includes('tiktok.com') || url.includes('tiktokcdn.com')) {
      detectVideoId(url, body && typeof body === 'string' ? body : null);
      detectFileKey(url, body);

      // Modify publish
      if (typeof body === 'string' && url.includes('project/post')) {
        body = modifyPublishBody(url, body);
      }

      this.addEventListener('load', () => {
        try {
          if (this.responseText) detectVideoId(url, this.responseText);
          toBg({
            type: 'INTERCEPTED_DATA',
            data: {
              url, method: this._ttMethod || 'GET', ts: Date.now(),
              reqBody: body && typeof body === 'string' ? body.slice(0, 5000) : null,
              resBody: this.responseText ? this.responseText.slice(0, 5000) : null,
              status: this.status,
            }
          });
        } catch (e) {}
      });
    }

    return _xhrSend.call(this, body);
  };

  console.log('[Maska-int] Interceptor ready');
})();
