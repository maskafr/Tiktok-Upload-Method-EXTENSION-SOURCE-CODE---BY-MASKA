/**
 * TT Analytics — Background Service Worker (v5)
 *
 * v5: NEW METHODS for 1080p:
 *  - spoofMobileUA: replaces User-Agent with TikTok Android for key APIs (via declarativeNetRequest)
 *  - spoofDevicePlatform: replaces device_platform=web → android in URL (via interceptor)
 *  - addHDParams: mobile HD parameters in publish body
 *  - forceVideoCanvas: cloud_edit_is_use_video_canvas=true
 *  - pollTranscode DISABLED by default (confirmed useless across 7 tests)
 *
 * HAR analysis showed:
 *  - TikTok KNOWS video is 1080p (CDN: OriginHeight=1080, Height=1080)
 *  - Compression to 720p happens server-side after upload
 *  - transcode/enable gives 60fps (works!) but not 1080p
 *  - cloud_edit_video_height in publish body DOES NOT affect output resolution
 *  - device_platform=web in upload URL — possible key to 720p limitation
 */

const TT_URL_FILTER = [
  "*://*.tiktok.com/*",
  "*://*.tiktokcdn.com/*",
  "*://*.tiktokv.com/*",
  "*://*.byteoversea.com/*"
];

const DEFAULT_CONFIG = {
  enabled: true,
  loggingEnabled: true,
  methods: {
    transcodeEnable: true,
    pollTranscode: false,        // DISABLED — confirmed useless (7 tests, always status=0)
    modifyPublishBody: true,
    privateFirst: true,
    modifyCloudEdit: false,      // Doesn't work — cloud_edit_video_height doesn't affect quality
    modifyEntryPoint: false,
    modifySinglePostInfo: false,
    removeDraft: true,
    removeCloudEdit: true,       // Remove cloud_edit — let TikTok determine it
    // === NEW v5 methods ===
    spoofMobileUA: false,        // Replace User-Agent with TikTok Android
    spoofDevicePlatform: false,  // device_platform=web → android in URL
    addHDParams: false,          // Mobile HD parameters in publish body
    forceVideoCanvas: false,     // cloud_edit_is_use_video_canvas=true
    spoofAid: false,             // aid=1988 → 1233 (mobile app ID)
    // === v6+ CONTAINER METADATA TESTS ===
    useIsomBrand: false,         // Set ftyp brand to 'isom' (trusted exporter branch)
    cleanMetadata: false,        // Remove FFmpeg encoder trace, preserve legacy signature
    dimensionMismatch: false,    // Container claims 720p, bitstream is 1080p (preflight bypass)
    moovTail: false,             // Move moov box to end of file
    useHEVC: false,              // Use H.265/HEVC codec in MOV container (different pipeline)
    highResClaim: false,         // Container claims 4K, bitstream is 1080p (reverse test)
    uuidAtomTail: false,         // Add small uuid atom at tail (trusted export profile)
    timescale90k: false,         // Set video timescale to 90000 (standard export)
    res1440With720Claim: false,  // Real 1440p, container claims 720p (high-res trigger + safe preflight)
    res4kWith1080Claim: false,   // Real 4K, container claims 1080p (max test)
  },
  params: {
    cloudEditHeight: 1080,
    cloudEditWidth: 1080,
    enterPostPageFrom: 2,
    transcodePollInterval: 1500,
    transcodePollMaxAttempts: 60,
    autoSwitchVisibilityDelay: 5000,
    singlePostHeight: 0,
    singlePostWidth: 0,
  },
  maxLogEntries: 3000,
  logBodies: true,
  maxBodySize: 30000,
};

let config = { ...DEFAULT_CONFIG };
let requestLog = [];
let sessions = [];
let activeSession = null;
let sessionCounter = 0;
let detectedVideoIds = new Set();

// file_key и duration, захваченные из нативного transcode/result (scene=1)
let capturedFileKey = null;
let capturedDuration = 0;
let transcodeCompleted = false;

// ═══ INIT ═══

async function ensureToolbarAction() {
  try {
    await chrome.action.setPopup({ popup: '' });
    await chrome.action.setIcon({
      path: {
        16: 'icons/icon16.png',
        32: 'icons/icon48.png',
        48: 'icons/icon48.png',
        128: 'icons/icon128.png',
      },
    });
  } catch (e) {
    console.warn('[Maska] toolbar setup failed:', e?.message);
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  const url = tab.url || '';
  if (!/tiktok\.com/i.test(url)) {
    chrome.tabs.create({ url: 'https://www.tiktok.com/' });
    return;
  }
  chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_PANEL' }).catch(() => {
    chrome.tabs.sendMessage(tab.id, { type: 'SHOW_PANEL' }).catch(() => {});
  });
});

chrome.runtime.onInstalled.addListener(async (details) => {
  const stored = await chrome.storage.local.get(['config']);
  if (stored.config) {
    config = mergeConfig(stored.config);
  }
  await chrome.storage.local.set({ config, requestLog: [], sessions: [], sessionCounter: 0 });
  await ensureToolbarAction();
  console.log('[Maska] Extension installed (reason:', details.reason + ')');

  // Setup UA spoofing
  await setupUASpoof();

  // On extension update — reload all TikTok tabs
  // to avoid "Extension context invalidated"
  if (details.reason === 'update' || details.reason === 'install') {
    chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
      for (const tab of tabs || []) {
        chrome.tabs.reload(tab.id).catch(() => {});
      }
      if (tabs?.length) {
        console.log('[TT] Reloaded', tabs.length, 'TikTok tabs');
      }
    });
  }
});

chrome.runtime.onStartup.addListener(async () => {
  const stored = await chrome.storage.local.get(['config', 'requestLog', 'sessions', 'sessionCounter']);
  if (stored.config) config = mergeConfig(stored.config);
  if (stored.requestLog) requestLog = stored.requestLog;
  if (stored.sessions) sessions = stored.sessions;
  if (stored.sessionCounter) sessionCounter = stored.sessionCounter;
  await ensureToolbarAction();
  await setupUASpoof();
});

function mergeConfig(saved) {
  return {
    ...DEFAULT_CONFIG, ...saved,
    methods: { ...DEFAULT_CONFIG.methods, ...(saved.methods || {}) },
    params: { ...DEFAULT_CONFIG.params, ...(saved.params || {}) },
  };
}

// ═══ UA SPOOFING via declarativeNetRequest ═══

const MOBILE_UA = 'com.zhiliaoapp.musically/390503 (Linux; U; Android 14; en_US; Pixel 8 Pro; Build/UP1A.231005.007; Cronet/TTNetVersion:0ac18c9e 2024-12-18 QuicVersion:b3702537 2024-12-16)';
const UA_RULE_IDS = [1001, 1002, 1003];

async function setupUASpoof() {
  try {
    // First remove old rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: UA_RULE_IDS
    });

    if (!config.enabled || !config.methods.spoofMobileUA) {
      console.log('[TT] UA spoofing DISABLED');
      return;
    }

    // Create rules for key APIs
    const rules = [
      {
        id: 1001,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'User-Agent', operation: 'set', value: MOBILE_UA },
            { header: 'x-tt-app-name', operation: 'set', value: 'musically' },
          ]
        },
        condition: {
          urlFilter: '*tiktok.com/api/v1/video/transcode*',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 1002,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'User-Agent', operation: 'set', value: MOBILE_UA },
            { header: 'x-tt-app-name', operation: 'set', value: 'musically' },
          ]
        },
        condition: {
          urlFilter: '*tiktok.com/tiktok/web/project/post*',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 1003,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'User-Agent', operation: 'set', value: MOBILE_UA },
            { header: 'x-tt-app-name', operation: 'set', value: 'musically' },
          ]
        },
        condition: {
          urlFilter: '*tiktokcdn.com/upload*',
          resourceTypes: ['xmlhttprequest']
        }
      },
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: rules
    });

    console.log('[TT] ✅ UA spoofing ENABLED for', rules.length, 'URL patterns');
    console.log('[TT] Mobile UA:', MOBILE_UA.slice(0, 60) + '...');
  } catch (err) {
    console.error('[TT] ❌ Error setting up UA spoof:', err.message);
  }
}

// ═══ WEBREQUEST — MONITORING ═══

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (!config.loggingEnabled) return;
    const cat = categorize(details.url);
    if (cat === 'SKIP') return;

    const entry = {
      id: genId(), ts: Date.now(), time: new Date().toISOString(),
      method: details.method, url: details.url, cat,
      status: null, duration: null, reqBody: null, resBody: null,
      _start: Date.now(),
    };

    if (details.requestBody && config.logBodies) {
      if (details.requestBody.raw) {
        const sz = details.requestBody.raw.reduce((s, p) => s + (p.bytes ? p.bytes.byteLength : 0), 0);
        entry.reqBody = '[Binary: ' + fmtBytes(sz) + ']';
        // Capture file_key from native transcode/result (scene=1)
        if (cat === 'TRANSCODE_POLL' && details.method === 'POST') {
          tryExtractFileKey(details.requestBody.raw);
        }
      } else if (details.requestBody.formData) {
        entry.reqBody = details.requestBody.formData;
      }
    }

    addLog(entry);

    // === VIDEO_ID EXTRACTION ===
    const vid = extractVideoId(details.url);
    if (vid) handleVideoId(vid, cat, details.tabId);

    // === SESSION START ===
    if (cat === 'UPLOAD_AUTH' || cat === 'APPLY_UPLOAD') startSession(details.tabId);
  },
  { urls: TT_URL_FILTER },
  ["requestBody"]
);

chrome.webRequest.onCompleted.addListener(
  (details) => {
    const entry = findLog(details.url);
    if (entry) {
      entry.status = details.statusCode;
      entry.duration = Date.now() - (entry._start || Date.now());
    }
  },
  { urls: TT_URL_FILTER }
);

// ═══ FILE_KEY CAPTURE ═══

function tryExtractFileKey(rawParts) {
  try {
    // WebRequest raw body — array of ArrayBuffer
    for (const part of rawParts) {
      if (!part.bytes) continue;
      const text = new TextDecoder('utf-8').decode(part.bytes);
      // Try to parse JSON (transcode/result POST body)
      try {
        const json = JSON.parse(text);
        if (json.video_info && Array.isArray(json.video_info)) {
          for (const vi of json.video_info) {
            if (vi.file_key && vi.file_key.startsWith('file_')) {
              capturedFileKey = vi.file_key;
              console.log('[TT] 🔑 file_key captured:', capturedFileKey);
            }
            if (vi.original_duration_ms && vi.original_duration_ms > 0) {
              capturedDuration = vi.original_duration_ms;
              console.log('[TT] ⏱️ duration captured:', capturedDuration, 'ms');
            }
          }
        }
      } catch (e) { /* not JSON — OK */ }
    }
  } catch (e) {
    console.warn('[TT] Error parsing file_key:', e.message);
  }
}

// ═══ VIDEO_ID ═══

function extractVideoId(url) {
  const m = url.match(/video_id=(v[0-9a-z]+)/i);
  return m ? m[1] : null;
}

function handleVideoId(videoId, source, tabId) {
  if (detectedVideoIds.has(videoId)) return;
  detectedVideoIds.add(videoId);

  console.log('[TT] Video ID:', videoId, 'from', source);

  if (activeSession) {
    activeSession.videoId = videoId;
    activeSession.events.push({ t: Date.now(), type: 'VIDEO_ID', source, videoId });
  }

  notify({ type: 'VIDEO_ID_DETECTED', videoId, source });

  if (config.enabled && config.methods.transcodeEnable) {
    console.log('[TT] Calling transcode/enable DIRECTLY for', videoId);
    console.log('[TT] file_key captured:', capturedFileKey ? 'YES (' + capturedFileKey + ')' : 'NO');
    console.log('[TT] duration:', capturedDuration, 'ms');
    transcodeCompleted = false;
    callTranscodeEnableDirect(videoId, tabId);
  }
}

// ═══ TRANSCODE/ENABLE — DIRECT CALL FROM BACKGROUND ═══

async function callTranscodeEnableDirect(videoId, tabId) {
  const apiUrl = 'https://www.tiktok.com/api/v1/video/transcode/enable/?video_id=' +
    encodeURIComponent(videoId) + '&aid=1988';

  try {
    // Get cookies for tiktok.com
    const cookies = await chrome.cookies.getAll({ domain: '.tiktok.com' });
    const cookieStr = cookies.map(c => c.name + '=' + c.value).join('; ');

    // Step 1: HEAD for CSRF
    const headRes = await fetch(apiUrl, {
      method: 'HEAD',
      headers: {
        'Cookie': cookieStr,
        'x-secsdk-csrf-request': '1',
        'x-secsdk-csrf-version': '1.2.22',
        'Referer': 'https://www.tiktok.com/',
        'Origin': 'https://www.tiktok.com',
      }
    });

    const csrfHeader = headRes.headers.get('x-ware-csrf-token');
    let token = null;
    if (csrfHeader) {
      const parts = csrfHeader.split(',');
      if (parts.length >= 2) token = parts[1];
    }

    console.log('[TT] BG CSRF token:', token ? 'received' : 'NOT RECEIVED (trying via content script)');

    // If CSRF not received from background, try via content script as fallback
    if (!token) {
      console.log('[TT] Fallback: trying via content script...');
      sendToTab(tabId, {
        type: 'CALL_TRANSCODE_ENABLE',
        videoId,
        poll: config.methods.pollTranscode,
        pollInterval: config.params.transcodePollInterval,
        pollMax: config.params.transcodePollMaxAttempts,
      });
      return;
    }

    // Step 2: POST
    const postRes = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Cookie': cookieStr,
        'Content-Type': 'application/x-www-form-urlencoded',
        'x-secsdk-csrf-version': '1.2.22',
        'tt-csrf-token': token,
        'x-secsdk-csrf-token': token,
        'Referer': 'https://www.tiktok.com/',
        'Origin': 'https://www.tiktok.com',
      }
    });

    const result = await postRes.json();
    console.log('[TT] ✅ BG transcode/enable result:', result);

    // Notify
    sendToTab(tabId, { type: 'SHOW_NOTIFICATION', text: 'transcode/enable: OK ✓', notifType: 'success' });

    if (activeSession) {
      activeSession.transcodeEnabled = true;
      activeSession.transcodeStatus = 'enabled';
      activeSession.methodsUsed.push('transcode_enable');
      activeSession.events.push({ t: Date.now(), type: 'TRANSCODE', status: 'enabled', detail: JSON.stringify(result).slice(0, 500) });
    }
    notify({ type: 'TRANSCODE_UPDATE', status: 'enabled', videoId });

    // Step 3: Polling
    if (config.methods.pollTranscode) {
      pollTranscodeResultDirect(videoId, tabId, config.params.transcodePollInterval, config.params.transcodePollMaxAttempts);
    }

  } catch (err) {
    console.error('[TT] ❌ BG transcode/enable error:', err.message);
    // Fallback to content script
    console.log('[TT] Fallback: trying via content script...');
    sendToTab(tabId, {
      type: 'CALL_TRANSCODE_ENABLE',
      videoId,
      poll: config.methods.pollTranscode,
      pollInterval: config.params.transcodePollInterval,
      pollMax: config.params.transcodePollMaxAttempts,
    });
  }
}

async function pollTranscodeResultDirect(videoId, tabId, interval, maxAttempts) {
  const url = 'https://www.tiktok.com/api/v1/video/transcode/result/?aid=1988';
  let attempts = 0;

  // Use captured file_key or generate
  const fileKey = capturedFileKey || ('file_' + Date.now() + '_' + Math.floor(Math.random() * 1000000));
  const duration = capturedDuration || 0;
  console.log('[TT] Polling with file_key:', fileKey, 'duration:', duration);

  const doPoll = async () => {
    if (attempts >= maxAttempts) {
      console.log('[TT] BG polling timeout after', attempts, 'attempts');
      sendToTab(tabId, { type: 'SHOW_NOTIFICATION', text: 'Transcode did not complete (' + attempts + ' polls). Publish as is.', notifType: 'warning' });
      return;
    }
    attempts++;

    try {
      const cookies = await chrome.cookies.getAll({ domain: '.tiktok.com' });
      const cookieStr = cookies.map(c => c.name + '=' + c.value).join('; ');

      // HEAD for CSRF
      const headRes = await fetch(url, {
        method: 'HEAD',
        headers: {
          'Cookie': cookieStr,
          'x-secsdk-csrf-request': '1',
          'x-secsdk-csrf-version': '1.2.22',
          'Referer': 'https://www.tiktok.com/',
          'Origin': 'https://www.tiktok.com',
        }
      });
      const csrfH = headRes.headers.get('x-ware-csrf-token');
      let tk = null;
      if (csrfH) { const p = csrfH.split(','); if (p.length >= 2) tk = p[1]; }

      const hdrs = {
        'Cookie': cookieStr,
        'Content-Type': 'application/json',
        'x-secsdk-csrf-version': '1.2.22',
        'Referer': 'https://www.tiktok.com/',
        'Origin': 'https://www.tiktok.com',
      };
      if (tk) { hdrs['tt-csrf-token'] = tk; hdrs['x-secsdk-csrf-token'] = tk; }

      // FIXED: correct body format as in native TikTok
      const body = JSON.stringify({
        scene: 0,
        video_info: [{
          file_key: fileKey,
          video_id: videoId,
          original_width: 1080,
          original_height: 1080,
          original_duration_ms: duration
        }]
      });

      const res = await fetch(url, { method: 'POST', headers: hdrs, body });
      const data = await res.json();

      // FIXED: correct path to status (data.transcode_result[0].transcode_status)
      const tr = data?.transcode_result;
      const st = tr && tr[0] ? tr[0].transcode_status : undefined;
      const remaining = tr && tr[0] ? tr[0].transcode_remaining_time_ms : undefined;
      const playUrl = tr && tr[0] ? tr[0].play_url : undefined;
      const sizeBytes = tr && tr[0] ? tr[0].size_in_bytes : undefined;

      console.log('[TT] BG transcode polling #' + attempts + ': status=' + st +
        (remaining !== undefined ? ' remaining=' + remaining + 'ms' : '') +
        (sizeBytes ? ' size=' + fmtBytes(sizeBytes) : ''));

      if (activeSession) {
        activeSession.transcodeStatus = st === 3 ? 'completed' : 'polling';
        activeSession.methodsUsed.push('transcode_enable');
        activeSession.events.push({ t: Date.now(), type: 'TRANSCODE', status: st === 3 ? 'completed' : 'polling', detail: JSON.stringify(data).slice(0, 500) });
      }

      if (st === 3) {
        console.log('[TT] ✅ BG Transcode completed!' + (playUrl ? ' play_url present' : ''));
        transcodeCompleted = true;
        sendToTab(tabId, { type: 'SHOW_NOTIFICATION', text: '✅ Transcode ready! You can publish.', notifType: 'success' });
        // Notify interceptor that transcode completed
        sendToTab(tabId, { type: 'TRANSCODE_COMPLETED', videoId, playUrl });
        return;
      }

      if (st === 2 && remaining !== undefined) {
        // Show progress
        if (attempts % 5 === 0) {
          sendToTab(tabId, { type: 'SHOW_NOTIFICATION', text: 'Transcode: ~' + Math.ceil(remaining / 1000) + 's remaining...', notifType: 'info' });
        }
      }

      setTimeout(doPoll, interval);
    } catch (err) {
      console.error('[TT] BG polling error:', err.message);
      setTimeout(doPoll, interval);
    }
  };

  setTimeout(doPoll, interval);
}

// ═══ SESSIONS ═══

function startSession(tabId) {
  if (activeSession && Date.now() - activeSession._startTs < 60000) return;
  sessionCounter++;
  // Reset captured data for new session
  capturedFileKey = null;
  capturedDuration = 0;
  transcodeCompleted = false;
  activeSession = {
    id: sessionCounter, tabId, _startTs: Date.now(),
    startTime: new Date().toISOString(), endTime: null,
    videoId: null, status: 'uploading',
    transcodeEnabled: false, transcodeStatus: null,
    publishModified: false, methodsUsed: [],
    events: [{ t: Date.now(), type: 'START' }],
  };
  saveState();
}

function endSession(status) {
  if (!activeSession) return;
  activeSession.endTime = new Date().toISOString();
  activeSession.status = status || 'completed';
  activeSession.events.push({ t: Date.now(), type: 'END', status });
  delete activeSession._startTs;
  sessions.push(activeSession);
  activeSession = null;
  detectedVideoIds.clear();
  saveState();
}

// ═══ MESSAGES ═══

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case 'GET_CONFIG':
      sendResponse({ config, transcodeCompleted, capturedFileKey }); break;
    case 'SET_CONFIG':
      config = mergeConfig(msg.config);
      chrome.storage.local.set({ config });
      broadcastConfig();
      setupUASpoof(); // Update UA rules when config changes
      sendResponse({ ok: true }); break;
    case 'GET_LOG':
      sendResponse({ log: filterLog(msg.filter) }); break;
    case 'GET_SESSIONS':
      sendResponse({ sessions, active: activeSession }); break;
    case 'CLEAR_LOG':
      requestLog = [];
      chrome.storage.local.set({ requestLog: [] });
      sendResponse({ ok: true }); break;
    case 'CLEAR_SESSIONS':
      sessions = []; activeSession = null; detectedVideoIds.clear();
      chrome.storage.local.set({ sessions: [], sessionCounter: 0 });
      sendResponse({ ok: true }); break;
    case 'EXPORT':
      sendResponse({ data: JSON.stringify({ config, requestLog, sessions }, null, 2) }); break;
    case 'TRANSCODE_RESULT':
      if (activeSession) {
        activeSession.transcodeEnabled = true;
        activeSession.transcodeStatus = msg.status;
        activeSession.methodsUsed.push('transcode_enable');
        activeSession.events.push({ t: Date.now(), type: 'TRANSCODE', status: msg.status, detail: msg.detail });
      }
      notify({ type: 'TRANSCODE_UPDATE', ...msg });
      sendResponse({ ok: true }); break;
    case 'PUBLISH_INTERCEPTED':
      if (activeSession) {
        activeSession.publishModified = msg.modified;
        if (msg.modified) activeSession.methodsUsed.push('publish_modified');
        activeSession.events.push({ t: Date.now(), type: 'PUBLISH', modified: msg.modified });
        endSession('published');
      }
      notify({ type: 'PUBLISH_UPDATE', ...msg });
      sendResponse({ ok: true }); break;
    case 'INTERCEPTED_DATA':
      mergeData(msg.data);
      sendResponse({ ok: true }); break;
    case 'VIDEO_ID_FROM_PAGE':
      if (msg.videoId && sender.tab) handleVideoId(msg.videoId, 'interceptor', sender.tab.id);
      sendResponse({ ok: true }); break;
    case 'FILE_KEY_FROM_PAGE':
      if (msg.fileKey && msg.fileKey.startsWith('file_')) {
        capturedFileKey = msg.fileKey;
        console.log('[TT] 🔑 file_key из interceptor:', capturedFileKey);
      }
      if (msg.duration > 0) {
        capturedDuration = msg.duration;
        console.log('[TT] ⏱️ duration из interceptor:', capturedDuration);
      }
      sendResponse({ ok: true }); break;
    case 'VIDEO_STATS_UPDATE':
      notify({ type: 'VIDEO_STATS_UPDATE', stats: msg.stats });
      sendResponse({ ok: true }); break;
    case 'GET_VIDEO_STATS':
      if (sender.tab?.id) {
        chrome.tabs.sendMessage(sender.tab.id, { type: 'GET_VIDEO_STATS' })
          .then((stats) => sendResponse(stats || { watching: false }))
          .catch(() => sendResponse({ watching: false, state: 'No video' }));
        return true;
      }
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = tabs?.[0]?.id;
        if (!tabId) {
          sendResponse({ watching: false, state: 'No video' });
          return;
        }
        chrome.tabs.sendMessage(tabId, { type: 'GET_VIDEO_STATS' })
          .then((stats) => sendResponse(stats || { watching: false }))
          .catch(() => sendResponse({ watching: false, state: 'No video' }));
      });
      return true;
    default:
      sendResponse({}); break;
  }
  return true;
});

// ═══ HELPERS ═══

function categorize(url) {
  if (/mcs-sg|mon-va|mssdk|log-va|frontier-sg|webcast/.test(url)) return 'SKIP';
  if (/\.(css|woff2?|ico|svg|png|jpe?g|gif|webp|mp4|m3u8)\b/.test(url) && !url.includes('upload/v1')) return 'SKIP';
  if (url.includes('copyright/music/check')) return 'COPYRIGHT';
  if (url.includes('video/upload/auth')) return 'UPLOAD_AUTH';
  if (url.includes('ApplyUploadInner')) return 'APPLY_UPLOAD';
  if (url.includes('CommitUploadInner')) return 'COMMIT_UPLOAD';
  if (url.includes('upload/v1/') && url.includes('tiktokcdn.com')) return 'CHUNK';
  if (url.includes('transcode/enable')) return 'TRANSCODE_ON';
  if (url.includes('transcode/result')) return 'TRANSCODE_POLL';
  if (url.includes('project/post')) return 'PUBLISH';
  if (url.includes('content/check')) return 'CHECK';
  if (url.includes('privacy/setting')) return 'PRIVACY';
  return 'OTHER';
}

function findLog(url) {
  for (let i = requestLog.length - 1; i >= Math.max(0, requestLog.length - 100); i--) {
    if (requestLog[i].url === url) return requestLog[i];
  }
  return null;
}

function addLog(entry) {
  requestLog.push(entry);
  if (requestLog.length > config.maxLogEntries) requestLog = requestLog.slice(-Math.floor(config.maxLogEntries * 0.8));
  throttledSave();
  notify({ type: 'NEW_LOG', entry });
}

function mergeData(d) {
  if (!d?.url) return;
  const e = requestLog.find(e => e.url === d.url && Math.abs(e.ts - (d.ts || 0)) < 10000);
  if (e) {
    if (d.reqBody) e.reqBody = trunc(d.reqBody);
    if (d.resBody) e.resBody = trunc(d.resBody);
    if (d.status) e.status = d.status;
  } else {
    addLog({ id: genId(), ts: d.ts || Date.now(), time: new Date().toISOString(), method: d.method || 'GET', url: d.url, cat: categorize(d.url), status: d.status, reqBody: d.reqBody ? trunc(d.reqBody) : null, resBody: d.resBody ? trunc(d.resBody) : null, src: 'int' });
  }
}

function filterLog(f) {
  if (!f) return requestLog.slice(-500);
  let r = requestLog;
  if (f.cat) r = r.filter(e => e.cat === f.cat);
  if (f.q) { const q = f.q.toLowerCase(); r = r.filter(e => e.url.toLowerCase().includes(q)); }
  return r.slice(-(f.limit || 500));
}

function trunc(s) {
  if (!s) return s;
  const str = typeof s === 'string' ? s : JSON.stringify(s);
  return str.length > config.maxBodySize ? str.slice(0, config.maxBodySize) + '...' : s;
}

function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function fmtBytes(b) { return b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(2) + ' MB'; }

function sendToTab(tabId, msg) {
  if (tabId && tabId > 0) {
    chrome.tabs.sendMessage(tabId, msg).catch(() => {});
  } else {
    chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
      if (tabs?.length) chrome.tabs.sendMessage(tabs[0].id, msg).catch(() => {});
    });
  }
}

function notify(msg) { chrome.runtime.sendMessage(msg).catch(() => {}); }

function broadcastConfig() {
  chrome.tabs.query({ url: '*://*.tiktok.com/*' }, (tabs) => {
    for (const t of tabs || []) chrome.tabs.sendMessage(t.id, { type: 'CONFIG_UPDATED', config }).catch(() => {});
  });
}

let _sv = null;
function throttledSave() {
  if (_sv) return;
  _sv = setTimeout(() => {
    chrome.storage.local.set({ requestLog: requestLog.slice(-2000), sessions, sessionCounter });
    _sv = null;
  }, 3000);
}
function saveState() { chrome.storage.local.set({ sessions, sessionCounter }); }

console.log('[TT] Background v5 loaded.');
