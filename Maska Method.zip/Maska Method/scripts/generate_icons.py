"""Regenerate Maska Method extension icons — bold M logo."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent / "icons"

FONT_CANDIDATES = [
    "C:/Windows/Fonts/segoeuib.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
    "C:/Windows/Fonts/calibrib.ttf",
    "C:/Windows/Fonts/impact.ttf",
]


def load_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for path in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_vector_m(d: ImageDraw.ImageDraw, size: int) -> None:
    """Bold geometric M — readable at 16px."""
    cx, cy = size / 2, size / 2
    s = size * 0.36
    x0, y0 = cx - s, cy - s * 0.88
    x1, y1 = cx + s, cy + s * 0.88
    thick = max(2, size * 0.14)

    fill = (255, 255, 255, 255)

    # Left stem
    d.rectangle([x0, y0, x0 + thick, y1], fill=fill)
    # Right stem
    d.rectangle([x1 - thick, y0, x1, y1], fill=fill)
    # Left diagonal (top-left to center)
    d.polygon([
        (x0, y0),
        (x0 + thick, y0),
        (cx, cy - s * 0.05),
        (cx - thick * 0.55, cy - s * 0.05),
    ], fill=fill)
    # Right diagonal
    d.polygon([
        (x1, y0),
        (x1 - thick, y0),
        (cx, cy - s * 0.05),
        (cx + thick * 0.55, cy - s * 0.05),
    ], fill=fill)


def draw_icon(size: int) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Gradient background
    for y in range(size):
        t = y / max(size - 1, 1)
        r = int(124 * (1 - t) + 6 * t)
        g = int(58 * (1 - t) + 182 * t)
        b = int(237 * (1 - t) + 212 * t)
        d.line([(0, y), (size, y)], fill=(r, g, b, 255))

    pad = max(1, size // 14)
    radius = max(3, size // 6)
    d.rounded_rectangle(
        [pad, pad, size - pad - 1, size - pad - 1],
        radius=radius,
        fill=(12, 10, 20, 255),
    )

    if size >= 24:
        font_size = int(size * 0.62)
        font = load_font(font_size)
        d.text(
            (size / 2, size / 2 - size * 0.03),
            "M",
            fill=(255, 255, 255, 255),
            font=font,
            anchor="mm",
            stroke_width=max(1, size // 32),
            stroke_fill=(192, 132, 252, 180),
        )
    else:
        draw_vector_m(d, size)

    return img


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    base = draw_icon(128)
    for size in (16, 48, 128):
        out = base.resize((size, size), Image.Resampling.LANCZOS)
        path = ROOT / f"icon{size}.png"
        out.save(path, "PNG")
        print("wrote", path)


if __name__ == "__main__":
    main()
