(function () {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('playback-inject.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.type === 'EXTRACT_VIDEO_INFO') {
            extractVideoInfo().then(info => sendResponse(info))
                .catch(err => sendResponse({ error: err.message || 'Failed' }));
            return true;
        }
        if (msg.type === 'SET_PLAYBACK_RATE') {
            const rate = msg.rate || 1.0;
            const video = getActiveVideoElement();
            if (!video) {
                sendResponse({ error: 'No video found on screen' });
                return;
            }
            cleanupSlowmoFix(video);
            if (rate !== 1.0) {
                const cdnUrl = findCdnUrl();
                if (cdnUrl) {
                    video.muted = true;
                    video.__maskaOrigMuted = false;
                    const desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'playbackRate');
                    desc.set.call(video, rate);
                    Object.defineProperty(video, 'playbackRate', {
                        get: function() { return rate; },
                        set: function(v) {
                            if (v === 1.0 && rate !== 1.0) return;
                            desc.set.call(this, v);
                        },
                        configurable: true
                    });
                    const audio = document.createElement('audio');
                    audio.crossOrigin = 'anonymous';
                    audio.src = cdnUrl;
                    audio.playbackRate = 1.0;
                    audio.currentTime = video.currentTime;
                    audio.play().catch(() => {});
                    video.__maskaAudio = audio;
                    video.__maskaSyncInterval = setInterval(() => {
                        if (!video.__maskaAudio) return;
                        if (video.paused && !audio.paused) audio.pause();
                        if (!video.paused && audio.paused) audio.play().catch(() => {});
                    }, 300);
                    const onPause = () => { if (video.__maskaAudio) video.__maskaAudio.pause(); };
                    const onPlay = () => { if (video.__maskaAudio) video.__maskaAudio.play().catch(() => {}); };
                    const onSeeked = () => { if (video.__maskaAudio) video.__maskaAudio.currentTime = video.currentTime; };
                    video.addEventListener('pause', onPause);
                    video.addEventListener('play', onPlay);
                    video.addEventListener('seeked', onSeeked);
                    video.__maskaListeners = [['pause', onPause], ['play', onPlay], ['seeked', onSeeked]];
                    sendResponse({ message: 'Video → ' + rate + '× | Audio → 1× ✅ — ' + video.videoWidth + 'x' + video.videoHeight });
                } else {
                    video.preservesPitch = true;
                    const desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'playbackRate');
                    desc.set.call(video, rate);
                    Object.defineProperty(video, 'playbackRate', {
                        get: function() { return rate; },
                        set: function(v) {
                            if (v === 1.0 && rate !== 1.0) return;
                            desc.set.call(this, v);
                        },
                        configurable: true
                    });
                    sendResponse({ message: 'Video → ' + rate + '× (no CDN URL found, audio also sped up) — ' + video.videoWidth + 'x' + video.videoHeight });
                }
            } else {
                sendResponse({ message: 'Reset to 1× — ' + video.videoWidth + 'x' + video.videoHeight });
            }
            return;
        }
    });
    function cleanupSlowmoFix(video) {
        if (video.__maskaAudio) {
            video.__maskaAudio.pause();
            video.__maskaAudio.src = '';
            video.__maskaAudio = null;
        }
        if (video.__maskaSyncInterval) {
            clearInterval(video.__maskaSyncInterval);
            video.__maskaSyncInterval = null;
        }
        if (video.__maskaListeners) {
            video.__maskaListeners.forEach(([evt, fn]) => video.removeEventListener(evt, fn));
            video.__maskaListeners = null;
        }
        video.muted = video.__maskaOrigMuted || false;
        delete video.__maskaOrigMuted;
        delete video.playbackRate;
        video.playbackRate = 1.0;
    }
    function findCdnUrl() {
        try {
            const uniEl = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
            if (uniEl) {
                const data = JSON.parse(uniEl.textContent);
                const ds = data?.['__DEFAULT_SCOPE__'];
                if (ds) {
                    const item = ds['webapp.video-detail']?.itemInfo?.itemStruct;
                    if (item?.video) {
                        const v = item.video;
                        const addr = v.playAddr || v.downloadAddr;
                        if (typeof addr === 'string' && addr.startsWith('http')) return addr;
                        if (addr?.url_list?.length) return addr.url_list[0];
                        if (v.playAddr_h265?.url_list?.length) return v.playAddr_h265.url_list[0];
                        if (v.bitrateInfo?.length) {
                            for (const bi of v.bitrateInfo) {
                                if (bi.PlayAddr?.UrlList?.length) return bi.PlayAddr.UrlList[0];
                                if (bi.playAddr?.url_list?.length) return bi.playAddr.url_list[0];
                            }
                        }
                    }
                }
            }
        } catch (e) {}
        try {
            const nd = document.getElementById('__NEXT_DATA__');
            if (nd) {
                const data = JSON.parse(nd.textContent);
                const item = data?.props?.pageProps?.itemInfo?.itemStruct;
                if (item?.video) {
                    const addr = item.video.playAddr || item.video.downloadAddr;
                    if (typeof addr === 'string' && addr.startsWith('http')) return addr;
                    if (addr?.url_list?.length) return addr.url_list[0];
                }
            }
        } catch (e) {}
        try {
            const se = document.getElementById('SIGI_STATE');
            if (se) {
                const sigi = JSON.parse(se.textContent);
                const items = sigi?.ItemModule || {};
                for (const id in items) {
                    const v = items[id]?.video;
                    if (v) {
                        const addr = v.playAddr || v.downloadAddr;
                        if (typeof addr === 'string' && addr.startsWith('http')) return addr;
                        if (addr?.url_list?.length) return addr.url_list[0];
                    }
                }
            }
        } catch (e) {}
        return null;
    }
    function findCurrentVideoId() {
        const urlMatch = window.location.href.match(/\/video\/(\d+)/);
        if (urlMatch) return urlMatch[1];
        const videos = document.querySelectorAll('video');
        let activeVideo = null;
        let maxVisibility = 0;
        const centerY = window.innerHeight / 2;
        for (const v of videos) {
            const rect = v.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;
            const vCenter = rect.top + rect.height / 2;
            const dist = Math.abs(vCenter - centerY);
            if (!v.paused && dist < window.innerHeight / 2) {
                const visibility = 1000 - dist;
                if (visibility > maxVisibility) {
                    maxVisibility = visibility;
                    activeVideo = v;
                }
            }
        }
        if (!activeVideo && videos.length > 0) {
            let closestDist = Infinity;
            for (const v of videos) {
                const rect = v.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0) continue;
                const vCenter = rect.top + rect.height / 2;
                const dist = Math.abs(vCenter - centerY);
                if (dist < closestDist) {
                    closestDist = dist;
                    activeVideo = v;
                }
            }
        }
        if (!activeVideo) return null;
        let el = activeVideo;
        for (let i = 0; i < 20 && el; i++) {
            el = el.parentElement;
            if (!el) break;
            const containerLinks = el.querySelectorAll('a[href*="/video/"]');
            for (const link of containerLinks) {
                const m = link.href.match(/\/video\/(\d+)/);
                if (m) return m[1];
            }
            if (el.dataset && el.dataset.e2e === 'feed-video') {
                const links = el.querySelectorAll('a');
                for (const link of links) {
                    const m = link.href.match(/\/video\/(\d+)/);
                    if (m) return m[1];
                }
            }
            if (el.dataset && el.dataset.e2eItemId) return el.dataset.e2eItemId;
            if (el.id && /^\d{15,}$/.test(el.id)) return el.id;
        }
        try {
            const sigiEl = document.getElementById('SIGI_STATE');
            if (sigiEl) {
                const sigi = JSON.parse(sigiEl.textContent);
                const items = sigi?.ItemModule || {};
                const ids = Object.keys(items);
                if (ids.length === 1) return ids[0];
                if (ids.length > 0) return ids[0];
            }
        } catch (e) {}
        try {
            const uniEl = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
            if (uniEl) {
                const data = JSON.parse(uniEl.textContent);
                const defaultScope = data?.['__DEFAULT_SCOPE__'];
                if (defaultScope) {
                    const itemDetail = defaultScope['webapp.video-detail'];
                    if (itemDetail?.itemInfo?.itemStruct?.id) {
                        return itemDetail.itemInfo.itemStruct.id;
                    }
                }
            }
        } catch (e) {}
        return null;
    }
    function getActiveVideoElement() {
        const videos = document.querySelectorAll('video');
        for (const v of videos) {
            if (!v.paused && v.readyState >= 2) return v;
        }
        const centerY = window.innerHeight / 2;
        let best = null, bestDist = Infinity;
        for (const v of videos) {
            const rect = v.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;
            const dist = Math.abs(rect.top + rect.height / 2 - centerY);
            if (dist < bestDist) { bestDist = dist; best = v; }
        }
        return best;
    }
    async function extractVideoInfo() {
        const videoId = findCurrentVideoId();
        if (!videoId) {
            return { error: 'No video found. Make sure a TikTok video is visible on screen.' };
        }
        const info = { videoId };
        try {
            const timestamp = Number(BigInt(videoId) >> 32n);
            const date = new Date(timestamp * 1000);
            info.creationDate = date.toLocaleString('en-GB', {
                day: '2-digit', month: 'long', year: 'numeric',
                hour: '2-digit', minute: '2-digit', second: '2-digit',
                hour12: false
            });
        } catch (e) { info.creationDate = 'Unknown'; }
        const pageData = getPageVideoData(videoId);
        if (pageData) Object.assign(info, pageData);
        try {
            const apiData = await fetchVideoDetailsFromAPI(videoId);
            if (apiData) {
                for (const [k, v] of Object.entries(apiData)) {
                    if (info[k] === undefined || info[k] === 0 || info[k] === '' || info[k] === '?') {
                        info[k] = v;
                    }
                }
            }
        } catch (e) {}
        const videoEl = getActiveVideoElement();
        if (videoEl) {
            if (videoEl.videoWidth) info.playerWidth = videoEl.videoWidth;
            if (videoEl.videoHeight) info.playerHeight = videoEl.videoHeight;
            if (videoEl.duration && videoEl.duration !== Infinity) {
                info.duration = Math.round(videoEl.duration);
            }
            info.currentSrc = videoEl.currentSrc || videoEl.src || '';
        }
        return info;
    }
    function getPageVideoData(videoId) {
        const result = {};
        try {
            const uniEl = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
            if (uniEl) {
                const data = JSON.parse(uniEl.textContent);
                const defaultScope = data?.['__DEFAULT_SCOPE__'];
                if (defaultScope) {
                    const detail = defaultScope['webapp.video-detail'];
                    const item = detail?.itemInfo?.itemStruct;
                    if (item) {
                        parseItemStruct(item, result);
                        return result;
                    }
                }
            }
        } catch (e) {}
        try {
            const nextData = document.getElementById('__NEXT_DATA__');
            if (nextData) {
                const data = JSON.parse(nextData.textContent);
                const item = data?.props?.pageProps?.itemInfo?.itemStruct;
                if (item) {
                    parseItemStruct(item, result);
                    return result;
                }
            }
        } catch (e) {}
        try {
            const sigiEl = document.getElementById('SIGI_STATE');
            if (sigiEl) {
                const sigi = JSON.parse(sigiEl.textContent);
                const item = sigi?.ItemModule?.[videoId];
                if (item) {
                    parseItemStruct(item, result);
                    return result;
                }
            }
        } catch (e) {}
        return null;
    }
    function parseItemStruct(item, r) {
        r.author = item.author?.uniqueId || item.author || '';
        r.desc = item.desc || '';
        r.locationCreated = item.locationCreated || '';
        const video = item.video;
        if (video) {
            r.browserUrl = video.playAddr || video.downloadAddr || '';
            r.duration = video.duration || 0;
            r.format = video.format || 'mp4';
            r.codec = video.codecType || video.videoCodec || 'h264';
            r.width = video.width || 0;
            r.height = video.height || 0;
            r.bitrate = video.bitrate || 0;
            r.size = video.size || video.dataSize || 0;
            if (r.width && r.height) {
                const shortSide = Math.min(r.width, r.height);
                r.quality = shortSide >= 1080 ? '1080p' : shortSide >= 720 ? '720p' : shortSide + 'p';
            }
            if (video.bitrateInfo && video.bitrateInfo.length > 0) {
                const bi = video.bitrateInfo[0];
                r.fps = bi.FPS || bi.fps || bi.FrameRate || 0;
                if (!r.bitrate) r.bitrate = bi.Bitrate || bi.bitrate || 0;
                if (!r.codec) r.codec = bi.CodecType || bi.codecType || 'h264';
                if (!r.size) r.size = bi.Size || bi.size || 0;
            }
        }
        const stats = item.stats || item.statsV2;
        if (stats) {
            r.plays = parseInt(stats.playCount) || 0;
            r.likes = parseInt(stats.diggCount) || 0;
            r.comments = parseInt(stats.commentCount) || 0;
            r.shares = parseInt(stats.shareCount) || 0;
        }
    }
    async function fetchVideoDetailsFromAPI(videoId) {
        try {
            const resp = await fetch('https://www.tiktok.com/api/item/detail/?itemId=' + videoId, {
                credentials: 'include',
                headers: { 'Accept': 'application/json' }
            });
            if (!resp.ok) return null;
            const data = await resp.json();
            const item = data?.itemInfo?.itemStruct;
            if (!item) return null;
            const result = {};
            parseItemStruct(item, result);
            if (data?.shareMeta) {
                result.shareTitle = data.shareMeta.title || '';
            }
            if (data?.statusCode === 0) {
                result.shadowBan = 'No';
            } else if (data?.statusCode === 10204) {
                result.shadowBan = 'Video removed or hidden';
            } else if (data?.statusCode) {
                result.shadowBan = 'Possible (status: ' + data.statusCode + ')';
            }
            return result;
        } catch (e) {
            return null;
        }
    }
})();