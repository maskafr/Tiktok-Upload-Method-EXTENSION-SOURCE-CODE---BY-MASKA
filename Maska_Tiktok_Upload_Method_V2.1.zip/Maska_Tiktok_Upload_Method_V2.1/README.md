# MASKA Upload Method V2 (Chrome Extension)

## Installation (Developer Mode)

1. Open Chrome and go to `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder: `Maska Upload Method V2`.
5. Pin the extension and use the popup controls.

## Usage

1. Click the extension icon.
2. Turn the master switch **ON** (`ENABLED`).
3. Configure your desired quality settings (1080p/60fps by default).
4. Open TikTok Studio (`https://www.tiktok.com/tiktokstudio`...).
5. Upload your video normally.
6. The extension automatically intercepts and modifies upload requests.
7. Wait for the upload to finish — your video is now preserved at max quality!

> **Tip**: Check the interception log in the popup to see what's being modified/blocked in real-time.

## What This Extension Does

### Core System (Same as V1)
- Intercepts `fetch()` and `XMLHttpRequest` requests to `project/post`
- Modifies upload payloads to trick TikTok into treating edits as original uploads
- Changes `post_type` from 2 (edited) → 3 (original/direct)
- Removes `vedit_common_info.draft` and `vedit_segment_info`
- Blocks `URL.createObjectURL` to prevent client-side video re-encoding

### V2 Enhancements

| Feature | Description |
|---------|-------------|
| **1080p Unlock** | Forces resolution fields to 1080p in upload payloads |
| **60fps Preservation** | Forces fps/frame_rate to 60 on both mobile and web |
| **Network-Level Blocking** | Uses `declarativeNetRequest` to block compress/transcode endpoints |
| **Client Re-Encode Block** | Overrides `MediaSource`, `VideoEncoder`, `Canvas.toBlob`, `Worker` |
| **High Bitrate Mode** | Forces minimum 8Mbps (1080p) or 5Mbps (720p) bitrate |
| **Watermark Removal** | Strips watermark metadata from upload payloads |
| **HDR Passthrough** | Preserves HDR metadata instead of letting TikTok strip it |
| **Codec Lock** | Forces h264 codec for maximum compatibility |
| **WebSocket Guard** | Blocks quality-control messages sent via WebSocket |
| **Upload Config Override** | Intercepts upload configuration to force max quality settings |
| **Settings UI** | Quality/FPS selectors + 6 feature toggles |
| **Real-time Log** | Shows every intercepted/blocked request live |
| **Stats Tracking** | Counts total modifications and blocks |

## Files Overview

- `manifest.json` — MV3 manifest with `declarativeNetRequest`, `storage`, `tabs`
- `background.js` — Service worker: badge, rule toggling, settings relay, stats
- `main-content.js` — Content script bridge + enhanced toast notification
- `app-utils.js` — Core interception engine (10 sections, 500+ lines)
- `popup.html` / `popup.js` — Settings UI with log viewer
- `rules.json` — Declarative net request rules (5 blocking rules)
- `icons/` — PNG icons for Chrome (16, 48, 128)

## Permissions

- `storage` — Save settings and stats
- `declarativeNetRequest` — Block compression/transcode endpoints at network level
- `tabs` + `activeTab` — Badge updates and tab messaging

## Notes

- This extension targets TikTok Studio upload request patterns
- All interception only runs when the master switch is **ENABLED**
- Check the interception log to verify the extension is working
- If TikTok changes their upload API, the extension may need updates

## License

Copyright (c) 2026 Maska.

This project is licensed under the
[Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License](https://creativecommons.org/licenses/by-nc-nd/4.0/).
